// 예약 취소: 요청자 권한으로 cancel_reservation(권한·시간 검사, 재고 복구)을 먼저 실행하고,
// 성공하면 실제 결제였을 때만 토스 결제를 취소(환불)한다.
// Supabase 대시보드의 Edge Function 편집기에 이 파일 하나만 붙여 넣어도 동작하도록 공용 코드를 함께 담았다.
import { createClient } from 'npm:@supabase/supabase-js@2';

export const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

export function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });
}

export const env = (k: string) => Deno.env.get(k) ?? '';

/** 서버 전용(service role) 클라이언트 */
export const admin = () => createClient(env('SUPABASE_URL'), env('SUPABASE_SERVICE_ROLE_KEY'), { auth: { persistSession: false } });

/** 요청한 사용자 권한으로 동작하는 클라이언트 */
export const asUser = (req: Request) => createClient(env('SUPABASE_URL'), env('SUPABASE_ANON_KEY'), {
  auth: { persistSession: false },
  global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
});

/** 토스페이먼츠 API 호출 (시크릿 키는 서버에만 둔다) */
export async function toss(path: string, body: unknown) {
  const key = env('TOSS_SECRET_KEY');
  const res = await fetch(`https://api.tosspayments.com${path}`, {
    method: 'POST',
    headers: { Authorization: 'Basic ' + btoa(key + ':'), 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, data };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const { id } = await req.json();
    if (typeof id !== 'string') return json({ code: 'BAD_REQUEST' }, 400);
    const { data: r, error } = await asUser(req).rpc('cancel_reservation', { p_id: id });
    if (error) {
      const code = (error.message.match(/[A-Z_]{3,}/) ?? ['CANCEL_FAILED'])[0];
      return json({ code }, 409);
    }
    let refunded = false;
    const { data: row } = await admin().from('reservations').select('payment_key').eq('id', r.id).single();
    const key: string | null = row?.payment_key ?? null;
    if (key && !key.startsWith('demo_') && env('TOSS_SECRET_KEY')) {
      const t = await toss(`/v1/payments/${key}/cancel`, { cancelReason: '예약 취소' });
      refunded = t.ok;
    }
    return json({ ok: true, refunded });
  } catch (e) {
    return json({ code: 'SERVER_ERROR', message: String(e) }, 500);
  }
});
