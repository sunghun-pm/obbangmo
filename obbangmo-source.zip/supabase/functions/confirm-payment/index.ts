// 결제 승인: 선점(held) 예약을 확인하고, 토스 결제를 승인한 뒤 booked로 바꾼다.
// TOSS_SECRET_KEY가 없고 DEMO_PAYMENTS=true이면 데모 결제(실제 승인 없이 확정)를 허용한다.
// Supabase 대시보드의 Edge Function 편집기에 이 파일 하나만 붙여 넣어도 동작하도록 공용 코드를 함께 담았다.
import { createClient } from 'npm:@supabase/supabase-js@2';

export const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

export function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });
}

export const env = (k: string) => Deno.env.get(k) ?? '';

/** 서버 전용(service role) 클라이언트 */
export const admin = () => createClient(env('SUPABASE_URL'), env('SUPABASE_SERVICE_ROLE_KEY'), { auth: { persistSession: false } });

/** 요청한 사용자 권한으로 동작하는 클라이언트 */
export const asUser = (req: Request) => createClient(env('SUPABASE_URL'), env('SUPABASE_ANON_KEY'), {
  auth: { persistSession: false },
  global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
});

/** 토스페이먼츠 API 호출 (시크릿 키는 서버에만 둔다) */
export async function toss(path: string, body: unknown) {
  const key = env('TOSS_SECRET_KEY');
  const res = await fetch(`https://api.tosspayments.com${path}`, {
    method: 'POST',
    headers: { Authorization: 'Basic ' + btoa(key + ':'), 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, data };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const { orderId, amount, paymentKey, demo } = await req.json();
    if (typeof orderId !== 'string' || typeof amount !== 'number') return json({ code: 'BAD_REQUEST' }, 400);

    const { data: u } = await asUser(req).auth.getUser();
    if (!u.user) return json({ code: 'LOGIN_REQUIRED' }, 401);

    const db = admin();
    const { data: r } = await db.from('reservations').select('id,user_id,status,amount,hold_expires_at').eq('order_id', orderId).maybeSingle();
    if (!r || r.user_id !== u.user.id) return json({ code: 'NOT_FOUND' }, 404);
    if (r.status === 'booked') return json({ reservationId: r.id });
    if (r.status !== 'held' || r.amount !== amount || new Date(r.hold_expires_at).getTime() < Date.now()) return json({ code: 'NOT_HELD' }, 409);

    let key: string;
    if (demo) {
      if (env('DEMO_PAYMENTS') !== 'true') return json({ code: 'DEMO_DISABLED' }, 403);
      key = 'demo_' + crypto.randomUUID();
    } else {
      if (!env('TOSS_SECRET_KEY') || typeof paymentKey !== 'string') return json({ code: 'PAYMENT_NOT_CONFIGURED' }, 400);
      const t = await toss('/v1/payments/confirm', { paymentKey, orderId, amount });
      if (!t.ok) return json({ code: 'PAYMENT_FAILED', message: t.data?.message }, 402);
      key = paymentKey;
    }

    const { data: booked, error } = await db.rpc('mark_booked', { p_order_id: orderId, p_payment_key: key, p_amount: amount });
    if (error) {
      // 승인은 됐는데 확정에 실패하면(예: 그 사이 만료) 결제를 되돌린다
      if (!demo) await toss(`/v1/payments/${paymentKey}/cancel`, { cancelReason: '예약 확정 실패' });
      return json({ code: 'NOT_HELD' }, 409);
    }
    return json({ reservationId: booked.id });
  } catch (e) {
    return json({ code: 'SERVER_ERROR', message: String(e) }, 500);
  }
});
