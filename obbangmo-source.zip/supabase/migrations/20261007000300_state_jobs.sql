create extension if not exists pg_cron with schema pg_catalog;
grant usage on schema cron to postgres;
-- 9단계. 상태 자동 전환 (Supabase: Database > Extensions에서 pg_cron 켜기)
create or replace function public.run_state_jobs() returns void
language plpgsql security definer set search_path = public as $$
begin
  -- 10분 안에 결제하지 않은 선점: 만료 + 재고 복구
  with x as (
    update reservations set status = 'expired'
     where status = 'held' and hold_expires_at < now()
    returning listing_id, qty)
  update listings l set qty_left = l.qty_left + s.q
    from (select listing_id, sum(qty) q from x group by listing_id) s
   where l.id = s.listing_id;
  -- 픽업 종료 시각이 지난 확정 예약: 미수령
  update reservations r set status = 'no_show'
    from listings l
   where r.listing_id = l.id and r.status = 'booked' and l.pickup_end < now();
end $$;
revoke execute on function public.run_state_jobs() from public, anon, authenticated;

select cron.schedule('obm-state-jobs', '* * * * *', $$select public.run_state_jobs()$$);
select cron.schedule('obm-seed-demo', '5 15 * * *', $$select public.seed_demo_day()$$); -- UTC 15:05 = KST 00:05
