-- 2-A. 테이블과 권한(RLS)
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'user' check (role in ('user','owner')),
  nickname text,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, role, nickname)
  values (new.id,
          coalesce(nullif(new.raw_user_meta_data->>'role',''), 'user'),
          new.raw_user_meta_data->>'nickname');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create table public.stores (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id),
  name text not null,
  address text,
  lat double precision not null,
  lng double precision not null,
  created_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 20),
  category text not null check (category in ('빵','베이글','디저트')),
  orig_price int not null check (orig_price >= 1000),
  price int not null,
  constraint price_max_half check (price > 0 and price % 100 = 0 and price * 2 <= orig_price),
  items_desc text not null check (char_length(items_desc) between 1 and 80),
  allergens text[] not null default '{}',
  default_qty int not null default 4 check (default_qty between 1 and 20),
  default_start time not null default '19:00',
  default_end time not null default '20:30',
  photo_url text,
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  constraint default_window_valid check (default_end > default_start)
);

create table public.listings (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id),
  store_id uuid not null references public.stores(id) on delete cascade,
  sale_date date not null default (now() at time zone 'Asia/Seoul')::date,
  title text not null,
  category text not null,
  orig_price int not null,
  price int not null,
  items_desc text not null,
  allergens text[] not null default '{}',
  photo_url text,
  qty_total int not null check (qty_total between 0 and 40),
  qty_left int not null check (qty_left >= 0),
  pickup_start timestamptz not null,
  pickup_end timestamptz not null,
  closed_at timestamptz,
  created_at timestamptz not null default now(),
  unique (product_id, sale_date),
  check (pickup_end > pickup_start)
);

create table public.reservations (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id),
  store_id uuid not null references public.stores(id),
  sale_date date not null,
  user_id uuid not null references auth.users(id),
  qty int not null check (qty between 1 and 2),
  amount int not null,
  pickup_code text not null check (pickup_code ~ '^[0-9]{4}$'),
  order_id text not null unique,
  status text not null default 'held'
    check (status in ('held','booked','picked','expired','canceled','no_show')),
  hold_expires_at timestamptz,
  payment_key text,
  booked_at timestamptz, picked_at timestamptz, canceled_at timestamptz,
  created_at timestamptz not null default now()
);
create unique index reservations_code_per_store_day
  on public.reservations (store_id, sale_date, pickup_code)
  where status in ('held','booked','picked');
create index on public.reservations (listing_id);
create index on public.reservations (user_id);

-- RLS: 읽기는 정책으로, 재고·예약 변경은 모두 2-B의 함수로만
alter table public.profiles enable row level security;
alter table public.stores enable row level security;
alter table public.products enable row level security;
alter table public.listings enable row level security;
alter table public.reservations enable row level security;

create policy "본인 프로필 읽기" on public.profiles for select using (id = auth.uid());
create policy "본인 프로필 수정" on public.profiles for update using (id = auth.uid())
  with check (id = auth.uid() and role = (select p.role from public.profiles p where p.id = auth.uid()));

create policy "매장 공개 읽기" on public.stores for select using (true);
create policy "사장님 매장 등록" on public.stores for insert with check (owner_id = auth.uid());
create policy "사장님 매장 수정" on public.stores for update using (owner_id = auth.uid());

create policy "상품 공개 읽기" on public.products for select using (deleted_at is null
  or exists (select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()));
create policy "사장님 상품 등록" on public.products for insert
  with check (exists (select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()));
create policy "사장님 상품 수정" on public.products for update
  using (exists (select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()));

create policy "판매 공개 읽기" on public.listings for select using (true);

create policy "예약 읽기: 본인 또는 해당 매장 사장님" on public.reservations for select
  using (user_id = auth.uid()
     or exists (select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()));

grant usage on schema public to anon, authenticated;
grant select on public.stores, public.products, public.listings to anon, authenticated;
grant select, update on public.profiles to authenticated;
grant insert, update on public.stores, public.products to authenticated;
grant select on public.reservations to authenticated;

-- 상품 사진 버킷 (공개 읽기, 로그인 사용자 업로드)
insert into storage.buckets (id, name, public) values ('product-photos', 'product-photos', true)
  on conflict (id) do nothing;
create policy "상품 사진 업로드" on storage.objects for insert to authenticated
  with check (bucket_id = 'product-photos');

-- 실시간 갱신
alter publication supabase_realtime add table public.listings, public.reservations;
-- 2-B. 재고·예약 함수 (모든 변경은 여기서만)
create or replace function public.kst_today() returns date
language sql stable as $$ select (now() at time zone 'Asia/Seoul')::date $$;

-- 사장님: 오늘 판매 올리기
create or replace function public.open_listing(p_product_id uuid, p_qty int, p_start time, p_end time)
returns public.listings language plpgsql security definer set search_path = public as $$
declare p public.products; l public.listings; d date := public.kst_today();
begin
  select pr.* into p from products pr join stores s on s.id = pr.store_id
   where pr.id = p_product_id and pr.deleted_at is null and s.owner_id = auth.uid();
  if not found then raise exception 'NOT_OWNER'; end if;
  if p_qty not between 1 and 20 then raise exception 'BAD_QTY'; end if;
  if p_end <= p_start then raise exception 'BAD_WINDOW'; end if;
  insert into listings (product_id, store_id, sale_date, title, category, orig_price, price,
                        items_desc, allergens, photo_url, qty_total, qty_left, pickup_start, pickup_end)
  values (p.id, p.store_id, d, p.title, p.category, p.orig_price, p.price, p.items_desc,
          p.allergens, p.photo_url, p_qty, p_qty,
          (d + p_start) at time zone 'Asia/Seoul', (d + p_end) at time zone 'Asia/Seoul')
  returning * into l;
  return l;
exception when unique_violation then raise exception 'ALREADY_OPEN';
end $$;

-- 사장님: 남은 수량 조정 (예약된 수량 아래로는 못 줄임)
create or replace function public.adjust_listing_qty(p_listing_id uuid, p_delta int)
returns public.listings language plpgsql security definer set search_path = public as $$
declare l public.listings;
begin
  update listings li set qty_left = li.qty_left + p_delta, qty_total = li.qty_total + p_delta
   where li.id = p_listing_id and li.qty_left + p_delta >= 0 and li.closed_at is null
     and exists (select 1 from stores s where s.id = li.store_id and s.owner_id = auth.uid())
  returning * into l;
  if not found then raise exception 'CANNOT_ADJUST'; end if;
  return l;
end $$;

-- 사장님: 오늘 판매 마감 (기존 예약은 유지)
create or replace function public.close_listing(p_listing_id uuid)
returns public.listings language plpgsql security definer set search_path = public as $$
declare l public.listings;
begin
  update listings li set closed_at = now()
   where li.id = p_listing_id and li.closed_at is null
     and exists (select 1 from stores s where s.id = li.store_id and s.owner_id = auth.uid())
  returning * into l;
  if not found then raise exception 'CANNOT_CLOSE'; end if;
  return l;
end $$;

-- 사용자: 재고 선점. 마지막 1개를 동시에 눌러도 조건부 UPDATE 한 번으로 한 명만 성공
create or replace function public.reserve(p_listing_id uuid, p_qty int)
returns public.reservations language plpgsql security definer set search_path = public as $$
declare l public.listings; r public.reservations; v_code text; v_mine int;
begin
  if auth.uid() is null then raise exception 'LOGIN_REQUIRED'; end if;
  if p_qty not between 1 and 2 then raise exception 'BAD_QTY'; end if;
  select coalesce(sum(qty),0) into v_mine from reservations
   where listing_id = p_listing_id and user_id = auth.uid() and status in ('held','booked','picked');
  if v_mine + p_qty > 2 then raise exception 'LIMIT_2'; end if;

  update listings set qty_left = qty_left - p_qty
   where id = p_listing_id and qty_left >= p_qty and closed_at is null and now() < pickup_end
  returning * into l;
  if not found then raise exception 'SOLD_OUT'; end if;

  loop
    v_code := lpad((floor(random() * 9000) + 1000)::int::text, 4, '0');
    begin
      insert into reservations (listing_id, store_id, sale_date, user_id, qty, amount,
                                pickup_code, order_id, hold_expires_at)
      values (l.id, l.store_id, l.sale_date, auth.uid(), p_qty, l.price * p_qty, v_code,
              'obm_' || replace(gen_random_uuid()::text, '-', ''), now() + interval '10 minutes')
      returning * into r;
      exit;
    exception when unique_violation then -- 같은 매장·날짜에 코드가 겹치면 다시 뽑기
    end;
  end loop;
  return r;
end $$;

-- 서버(결제 승인 Edge Function) 전용: 결제 승인 후 예약 확정
create or replace function public.mark_booked(p_order_id text, p_payment_key text, p_amount int)
returns public.reservations language plpgsql security definer set search_path = public as $$
declare r public.reservations;
begin
  update reservations set status = 'booked', payment_key = p_payment_key, booked_at = now(),
         hold_expires_at = null
   where order_id = p_order_id and status = 'held' and amount = p_amount
  returning * into r;
  if not found then raise exception 'NOT_HELD'; end if;
  return r;
end $$;

-- 사용자(픽업 시작 전) 또는 사장님(언제든) 취소. 재고를 되돌린다. 환불은 Edge Function이 처리
create or replace function public.cancel_reservation(p_id uuid)
returns public.reservations language plpgsql security definer set search_path = public as $$
declare r public.reservations; l public.listings; is_owner boolean;
begin
  select * into r from reservations where id = p_id for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  select * into l from listings where id = r.listing_id;
  is_owner := exists (select 1 from stores s where s.id = r.store_id and s.owner_id = auth.uid());
  if r.user_id <> auth.uid() and not is_owner then raise exception 'FORBIDDEN'; end if;
  if r.status not in ('held','booked') then raise exception 'NOT_CANCELABLE'; end if;
  if not is_owner and now() >= l.pickup_start then raise exception 'TOO_LATE'; end if;
  update reservations set status = 'canceled', canceled_at = now() where id = p_id returning * into r;
  update listings set qty_left = qty_left + r.qty where id = r.listing_id;
  return r;
end $$;

-- 사장님: 픽업 코드로 수령 처리
create or replace function public.confirm_pickup(p_code text)
returns public.reservations language plpgsql security definer set search_path = public as $$
declare r public.reservations;
begin
  update reservations re set status = 'picked', picked_at = now()
   where re.pickup_code = p_code and re.sale_date = public.kst_today() and re.status = 'booked'
     and exists (select 1 from stores s where s.id = re.store_id and s.owner_id = auth.uid())
  returning * into r;
  if not found then raise exception 'CODE_NOT_FOUND'; end if;
  return r;
end $$;

revoke execute on all functions in schema public from public, anon;
grant execute on function public.kst_today(), public.open_listing(uuid,int,time,time),
  public.adjust_listing_qty(uuid,int), public.close_listing(uuid), public.reserve(uuid,int),
  public.cancel_reservation(uuid), public.confirm_pickup(text) to authenticated;
grant execute on function public.mark_booked(text,text,int) to service_role;
