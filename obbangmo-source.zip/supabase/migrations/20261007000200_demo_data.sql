-- 2-C. 예시 매장과 매일 갱신되는 예시 판매
insert into public.stores (id, name, address, lat, lng) values
 ('00000000-0000-0000-0000-0000000000b1','망원 베이글랩','마포구 망원동 (예시)',37.5571,126.9058),
 ('00000000-0000-0000-0000-0000000000b2','달밤제과','마포구 망원동 (예시)',37.5538,126.9031),
 ('00000000-0000-0000-0000-0000000000b3','오후의 스콘','마포구 망원동 (예시)',37.5532,126.9072),
 ('00000000-0000-0000-0000-0000000000b4','연남 사워도우','마포구 연남동 (예시)',37.5590,126.9120),
 ('00000000-0000-0000-0000-0000000000b5','성미산 식빵공방','마포구 성산동 (예시)',37.5612,126.9095);

insert into public.products (store_id, title, category, orig_price, price, items_desc, allergens, default_qty, default_start, default_end) values
 ('00000000-0000-0000-0000-0000000000b1','베이글 마감박스','베이글',12000,3900,'플레인·어니언·블루베리 베이글 4~5개','{밀,우유,참깨}',6,'20:00','21:00'),
 ('00000000-0000-0000-0000-0000000000b2','디저트 마감박스','디저트',18000,5900,'조각케이크, 마들렌, 휘낭시에 등 3~4개','{밀,우유,계란,견과류}',4,'18:30','19:30'),
 ('00000000-0000-0000-0000-0000000000b3','스콘 마감박스','디저트',9000,2900,'플레인·얼그레이·초코 스콘 3개','{밀,우유,계란}',5,'19:30','20:30'),
 ('00000000-0000-0000-0000-0000000000b4','빵 마감박스','빵',20000,6900,'사워도우 1개와 식사빵 2~3개','{밀}',3,'19:00','20:00'),
 ('00000000-0000-0000-0000-0000000000b5','식빵 마감박스','빵',14000,4500,'우유식빵·밤식빵 등 식빵 2개','{밀,우유,계란}',3,'20:30','21:30');

-- 예시 매장(사장님 없음)의 오늘 판매를 만든다. 9단계 cron이 매일 0시 5분에 호출
create or replace function public.seed_demo_day() returns int
language plpgsql security definer set search_path = public as $$
declare d date := public.kst_today(); n int;
begin
  insert into listings (product_id, store_id, sale_date, title, category, orig_price, price, items_desc,
                        allergens, photo_url, qty_total, qty_left, pickup_start, pickup_end)
  select p.id, p.store_id, d, p.title, p.category, p.orig_price, p.price, p.items_desc, p.allergens,
         p.photo_url, p.default_qty, p.default_qty,
         (d + p.default_start) at time zone 'Asia/Seoul', (d + p.default_end) at time zone 'Asia/Seoul'
    from products p join stores s on s.id = p.store_id
   where s.owner_id is null and p.deleted_at is null
  on conflict (product_id, sale_date) do nothing;
  get diagnostics n = row_count;
  return n;
end $$;
revoke execute on function public.seed_demo_day() from public, anon, authenticated;
select public.seed_demo_day();
