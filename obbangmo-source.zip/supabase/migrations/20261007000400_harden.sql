-- Supabase는 public 스키마의 새 테이블·함수에 anon/authenticated 권한을 기본으로 준다.
-- 서버 전용 함수와 직접 쓰기를 명시적으로 막는다.
revoke execute on function public.mark_booked(text,text,int) from public, anon, authenticated;
revoke execute on function public.seed_demo_day() from public, anon, authenticated;
revoke execute on function public.run_state_jobs() from public, anon, authenticated;
revoke execute on function public.handle_new_user() from public, anon, authenticated;
revoke insert, update, delete, truncate on public.listings, public.reservations from anon, authenticated;
revoke insert, update, delete, truncate on public.stores, public.products, public.profiles from anon;
revoke delete, truncate on public.stores, public.products, public.profiles from authenticated;
-- 매장 정보를 고칠 때 소유자를 다른 사람으로 바꾸지 못하게
alter policy "사장님 매장 수정" on public.stores using (owner_id = auth.uid()) with check (owner_id = auth.uid());
alter policy "사장님 상품 수정" on public.products
  using (exists (select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()))
  with check (exists (select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()));
