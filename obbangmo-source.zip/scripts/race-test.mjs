// 마지막 1개에 20명이 동시에 예약하면 정확히 1명만 성공하는지 확인한다.
// 사용법: SUPABASE_URL=... SUPABASE_ANON_KEY=... SUPABASE_SERVICE_ROLE_KEY=... LISTING_ID=... node scripts/race-test.mjs
// (LISTING_ID를 비우면 오늘 판매 중인 아무 박스나 고른다. 테스트 사용자 20명을 만들고, 끝나면 선점을 되돌린다)
import { createClient } from '@supabase/supabase-js';

const { SUPABASE_URL: url, SUPABASE_ANON_KEY: anon, SUPABASE_SERVICE_ROLE_KEY: service } = process.env;
if (!url || !anon || !service) { console.error('SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY가 필요해요'); process.exit(2); }
const N = Number(process.env.N ?? 20);
const admin = createClient(url, service, { auth: { persistSession: false } });

let listingId = process.env.LISTING_ID;
if (!listingId) {
  const today = new Date(Date.now() + 9 * 3600e3).toISOString().slice(0, 10);
  const { data } = await admin.from('listings').select('id,title').eq('sale_date', today).is('closed_at', null).gt('pickup_end', new Date().toISOString()).limit(1);
  if (!data?.length) { console.error('오늘 판매 중인 박스가 없어요'); process.exit(2); }
  listingId = data[0].id;
}
const { data: before } = await admin.from('listings').select('qty_left').eq('id', listingId).single();
await admin.from('listings').update({ qty_left: 1 }).eq('id', listingId);

const clients = [];
for (let i = 0; i < N; i++) {
  const email = `race${i}@race.test`, password = 'race-test-pass-1';
  await admin.auth.admin.createUser({ email, password, email_confirm: true }).catch(() => {});
  const c = createClient(url, anon, { auth: { persistSession: false } });
  const { error } = await c.auth.signInWithPassword({ email, password });
  if (error) { console.error('로그인 실패', email, error.message); process.exit(2); }
  clients.push(c);
}

const results = await Promise.all(clients.map((c) => c.rpc('reserve', { p_listing_id: listingId, p_qty: 1 })));
const ok = results.filter((r) => !r.error);
const sold = results.filter((r) => r.error && /SOLD_OUT/.test(r.error.message)).length;
const other = results.length - ok.length - sold;
console.log(`성공 ${ok.length} / SOLD_OUT ${sold} / 기타 ${other}`);

// 정리: 만든 선점을 만료 처리하고 재고를 원래대로
await admin.from('reservations').update({ status: 'expired' }).in('id', ok.map((r) => r.data.id));
await admin.from('listings').update({ qty_left: before.qty_left }).eq('id', listingId);
process.exit(ok.length === 1 && other === 0 ? 0 : 1);
