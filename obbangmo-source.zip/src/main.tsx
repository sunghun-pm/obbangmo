import { StrictMode, useCallback, useEffect, useState, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import './index.css';
import { AuthProvider, useAuth } from './lib/auth';
import { supabase, supabaseConfigured } from './lib/supabase';
import { kstToday } from './lib/format';
import { useLiveReload } from './lib/hooks';
import { ToastProvider, Loading } from './components/ui';
import { AppShell } from './components/Layout';
import Login from './pages/Login';
import Home from './pages/Home';
import BoxDetail from './pages/BoxDetail';
import Checkout from './pages/Checkout';
import { PayFail, PaySuccess } from './pages/PayResult';
import Tickets from './pages/Tickets';
import Ticket from './pages/Ticket';
import OwnerToday from './pages/owner/OwnerToday';
import OwnerProducts from './pages/owner/OwnerProducts';
import ProductForm from './pages/owner/ProductForm';
import OwnerOrders from './pages/owner/OwnerOrders';
import { MyStoreProvider, useMyStore } from './pages/owner/store';

function RequireAuth({ children }: { children: ReactNode }) {
  const { ready, userId } = useAuth();
  const loc = useLocation();
  if (!ready) return <Loading />;
  if (!userId) return <Navigate to="/login" replace state={{ from: loc.pathname }} />;
  return <>{children}</>;
}

function RequireOwner({ children }: { children: ReactNode }) {
  const { ready, userId, role } = useAuth();
  const loc = useLocation();
  if (!ready) return <Loading />;
  if (!userId) return <Navigate to="/login" replace state={{ from: loc.pathname }} />;
  if (role !== 'owner') return <Navigate to="/" replace />;
  return <MyStoreProvider>{children}</MyStoreProvider>;
}

/** 사장님 영역 셸: 예약자 탭 배지(픽업 전 예약 수)를 계산한다 */
function OwnerShell() {
  const { store } = useMyStore();
  const [count, setCount] = useState(0);
  const load = useCallback(async () => {
    if (!store) return;
    const { count } = await supabase.from('reservations').select('id', { count: 'exact', head: true })
      .eq('store_id', store.id).eq('sale_date', kstToday()).eq('status', 'booked');
    setCount(count ?? 0);
  }, [store]);
  useEffect(() => {
    load();
    window.addEventListener('obm:orders-changed', load);
    return () => window.removeEventListener('obm:orders-changed', load);
  }, [load]);
  useLiveReload(['reservations'], load, { filter: store ? `store_id=eq.${store.id}` : undefined, pollMs: 10000 });
  return <AppShell ownerBadge={count} />;
}

function NotConfigured() {
  return (
    <div className="mx-auto max-w-[430px] p-6 text-sm">
      <h1 className="text-xl font-bold">환경 변수가 필요해요</h1>
      <p className="mt-2 text-muted">.env 파일에 VITE_SUPABASE_URL과 VITE_SUPABASE_ANON_KEY를 넣고 다시 실행해 주세요. README의 배포 단계를 참고하세요.</p>
    </div>
  );
}

function App() {
  if (!supabaseConfigured) return <NotConfigured />;
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route path="/" element={<Home />} />
        <Route path="/box/:id" element={<BoxDetail />} />
        <Route path="/login" element={<Login />} />
        <Route path="/checkout/:reservationId" element={<RequireAuth><Checkout /></RequireAuth>} />
        <Route path="/pay/success" element={<RequireAuth><PaySuccess /></RequireAuth>} />
        <Route path="/pay/fail" element={<PayFail />} />
        <Route path="/tickets" element={<RequireAuth><Tickets /></RequireAuth>} />
        <Route path="/tickets/:id" element={<RequireAuth><Ticket /></RequireAuth>} />
      </Route>
      <Route path="/owner" element={<RequireOwner><OwnerShell /></RequireOwner>}>
        <Route index element={<OwnerToday />} />
        <Route path="products" element={<OwnerProducts />} />
        <Route path="products/new" element={<ProductForm />} />
        <Route path="products/:id" element={<ProductForm />} />
        <Route path="orders" element={<OwnerOrders />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <App />
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  </StrictMode>,
);
