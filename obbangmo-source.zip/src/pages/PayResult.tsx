import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { confirmPayment } from '../lib/payments';
import { friendly } from '../lib/errors';
import { Loading, StickyCta } from '../components/ui';

/** 토스 결제 인증 성공 → 서버에서 승인 → 티켓으로 */
export function PaySuccess() {
  const [q] = useSearchParams();
  const nav = useNavigate();
  const [err, setErr] = useState<string | null>(null);
  const once = useRef(false);
  useEffect(() => {
    if (once.current) return;
    once.current = true;
    const paymentKey = q.get('paymentKey');
    const orderId = q.get('orderId');
    const amount = Number(q.get('amount'));
    if (!paymentKey || !orderId || !amount) { setErr('결제 정보가 올바르지 않아요.'); return; }
    confirmPayment({ paymentKey, orderId, amount })
      .then((r) => nav(`/tickets/${r.reservationId}`, { replace: true }))
      .catch((e) => setErr(friendly(e, '결제 승인에 실패했어요. 결제는 자동으로 취소돼요.')));
  }, [q, nav]);
  if (!err) return <Loading />;
  return (
    <div className="flex flex-1 flex-col">
      <div className="mx-4 mt-8 rounded-2xl bg-danger-soft p-5"><b className="text-danger">결제를 완료하지 못했어요</b><p className="mt-2">{err}</p></div>
      <StickyCta><Link to="/" className="block rounded-2xl bg-accent py-3.5 text-center font-bold text-accent-ink">근처 박스로 돌아가기</Link></StickyCta>
    </div>
  );
}

export function PayFail() {
  const [q] = useSearchParams();
  const listing = q.get('listing');
  const message = q.get('message') || '결제가 취소됐어요.';
  return (
    <div className="flex flex-1 flex-col">
      <div className="mx-4 mt-8 rounded-2xl bg-danger-soft p-5">
        <b className="text-danger">결제가 진행되지 않았어요</b>
        <p className="mt-2">{message}</p>
        <p className="mt-2 text-sm text-muted">잡아 둔 박스는 10분 뒤 자동으로 풀려요.</p>
      </div>
      <StickyCta><Link to={listing ? `/box/${listing}` : '/'} className="block rounded-2xl bg-accent py-3.5 text-center font-bold text-accent-ink">박스 정보로 돌아가기</Link></StickyCta>
    </div>
  );
}
