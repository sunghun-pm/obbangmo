import { useCallback, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import QRCode from 'qrcode';
import { supabase, type Reservation } from '../lib/supabase';
import { TICKET_LABEL, TICKET_TONE, durationText, hm, ticketState, windowText } from '../lib/format';
import { friendly } from '../lib/errors';
import { useLiveReload, useNow } from '../lib/hooks';
import { cancelReservation } from '../lib/payments';
import { BackBar, Button, ConfirmSheet, Loading, StickyCta, useToast } from '../components/ui';

export default function Ticket() {
  const { id } = useParams();
  const toast = useToast();
  const now = useNow();
  const [r, setR] = useState<Reservation | null | undefined>(undefined);
  const [qr, setQr] = useState<string>('');
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const { data } = await supabase.from('reservations').select('*, listings(*, stores(name,address))').eq('id', id!).maybeSingle();
    setR((data as Reservation) ?? null);
  }, [id]);
  useEffect(() => { load(); }, [load]);
  useLiveReload(['reservations'], load, { filter: `id=eq.${id}`, pollMs: 10000 });

  useEffect(() => {
    if (!r) return;
    const dark = matchMedia('(prefers-color-scheme: dark)').matches;
    QRCode.toDataURL(`OBBANGMO:${r.store_id}:${r.pickup_code}`, { margin: 1, width: 280, color: { dark: dark ? '#ECEDF7' : '#1B1E3A', light: dark ? '#181A2E' : '#FFFFFF' } }).then(setQr);
  }, [r?.store_id, r?.pickup_code]);

  if (r === undefined) return <Loading />;
  if (r === null || !r.listings) return <div><BackBar to="/tickets" label="내 예약" /><p className="p-6 text-muted">예약을 찾을 수 없어요.</p></div>;

  const l = r.listings;
  const st = ticketState(r, now);
  const line = {
    booked: `픽업 시작까지 ${durationText(new Date(l.pickup_start).getTime() - now)} 남았어요`,
    ready: `지금 매장에 가서 받을 수 있어요 · ${hm(l.pickup_end)}까지`,
    picked: '맛있게 드세요. 버려질 뻔한 빵을 구했어요.',
    no_show: '픽업 시간이 지나서 박스를 받지 못했어요',
    canceled: '예약을 취소했어요. 결제가 취소됐어요.',
    held: '결제가 아직 끝나지 않았어요',
    expired: '결제하지 않아 예약이 풀렸어요',
  }[st];

  async function doCancel() {
    setConfirm(false);
    setBusy(true);
    try {
      await cancelReservation(r!.id);
      toast('예약을 취소했어요');
      load();
    } catch (e) {
      toast(friendly(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-1 flex-col">
      <BackBar to="/tickets" label="내 예약" />
      <div className="mx-4 overflow-hidden rounded-3xl border border-line">
        <div className="bg-accent-soft p-5 text-center">
          <span className={`inline-block rounded-full px-3 py-0.5 text-xs font-bold ${TICKET_TONE[st]}`}>{TICKET_LABEL[st]}</span>
          <div className="mt-3 text-xs text-muted">픽업 코드</div>
          <div className="num font-display text-[56px] leading-tight tracking-[0.18em] text-accent" data-testid="pickup-code">{r.pickup_code}</div>
          {qr && <img src={qr} alt={`픽업 코드 ${r.pickup_code} QR`} className="mx-auto mt-2 h-36 w-36 rounded-lg" />}
        </div>
        <div className="border-t border-dashed border-line p-4">
          <b>{l.stores?.name}</b>
          <div className="text-xs text-muted">{l.title} × {r.qty} · <span className="num">{windowText(l)}</span></div>
          <p className="mt-2 text-sm">{line}</p>
        </div>
      </div>
      <p className="mt-3 px-4 text-xs text-muted">매장에서 이 화면을 보여주거나 코드 4자리를 말해 주세요. {l.stores?.address}</p>
      {st === 'booked' && (
        <StickyCta><Button variant="danger" className="w-full" disabled={busy} onClick={() => setConfirm(true)}>{busy ? '취소하는 중…' : '예약 취소'}</Button></StickyCta>
      )}
      <ConfirmSheet open={confirm} title="예약을 취소할까요?" body="결제한 금액은 전액 환불돼요. 박스는 다른 분이 예약할 수 있게 돼요."
        confirmLabel="예약 취소" danger onConfirm={doCancel} onClose={() => setConfirm(false)} />
    </div>
  );
}
