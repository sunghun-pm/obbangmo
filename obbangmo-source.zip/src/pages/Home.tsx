import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase, type Listing } from '../lib/supabase';
import { CATEGORIES, ORIGIN, canReserve, distText, distanceM, kstToday, listingOrder, listingState, pct, windowText, won } from '../lib/format';
import { useLiveReload, useNow } from '../lib/hooks';
import { useAuth } from '../lib/auth';
import { Badge, Empty, Loading, Thumb } from '../components/ui';
import MiniMap, { type Pin } from '../components/MiniMap';

export default function Home() {
  const nav = useNavigate();
  const now = useNow();
  const { userId } = useAuth();
  const [rows, setRows] = useState<Listing[] | null>(null);
  const [error, setError] = useState(false);
  const [filter, setFilter] = useState<string>('전체');

  const load = useCallback(async () => {
    const { data, error } = await supabase.from('listings')
      .select('*, stores(name,address,lat,lng)')
      .eq('sale_date', kstToday());
    if (error) { setError(true); return; }
    setError(false);
    setRows(data as Listing[]);
  }, []);
  useEffect(() => { load(); }, [load]);
  useLiveReload(['listings'], load);

  const list = useMemo(() => (rows ?? [])
    .filter((l) => filter === '전체' || l.category === filter)
    .map((l) => ({ l, st: listingState(l, now), d: l.stores ? distanceM(l.stores.lat, l.stores.lng) : 0 }))
    .sort((a, b) => listingOrder[a.st] - listingOrder[b.st] || a.d - b.d), [rows, filter, now]);

  const available = (rows ?? []).filter((l) => canReserve(listingState(l, now))).length;

  const pins: Pin[] = useMemo(() => {
    const byStore = new Map<string, Listing[]>();
    (rows ?? []).forEach((l) => byStore.set(l.store_id, [...(byStore.get(l.store_id) ?? []), l]));
    return [...byStore.entries()].map(([storeId, ls]) => {
      const open = ls.filter((l) => canReserve(listingState(l, now))).sort((a, b) => a.price - b.price);
      const pick = open[0] ?? ls[0];
      return {
        id: pick.id, storeId, lat: pick.stores?.lat ?? ORIGIN.lat, lng: pick.stores?.lng ?? ORIGIN.lng,
        label: open.length ? `${(pick.price / 1000).toFixed(1)}천` : '마감', active: open.length > 0,
      };
    });
  }, [rows, now]);
  const onPick = useCallback((p: Pin) => nav(`/box/${p.id}`), [nav]);

  return (
    <div>
      <header className="flex items-center justify-between px-4 pt-3 pb-3">
        <div>
          <div className="font-display text-2xl text-accent">오빵뭐</div>
          <div className="text-sm text-muted">📍 {ORIGIN.name} · 지금 예약할 수 있는 마감 박스 <b className="num text-ink">{available}</b>개</div>
        </div>
        {userId ? null : <Link to="/login" className="text-sm font-semibold text-muted">로그인</Link>}
      </header>
      <div className="flex gap-1.5 overflow-x-auto px-4 pb-3" role="group" aria-label="종류">
        {['전체', ...CATEGORIES].map((c) => (
          <button key={c} type="button" aria-pressed={filter === c} onClick={() => setFilter(c)}
            className={`shrink-0 rounded-full border px-3.5 py-1.5 font-medium ${filter === c ? 'border-ink bg-ink text-surface' : 'border-line'}`}>{c}</button>
        ))}
      </div>
      <MiniMap pins={pins} onPick={onPick} />
      {error && <p className="px-4 pb-2 text-sm text-danger">목록을 불러오지 못했어요. 잠시 후 다시 시도해 주세요.</p>}
      {rows === null ? <Loading /> : list.length === 0 ? (
        <Empty>오늘 올라온 마감 박스가 아직 없어요.<br />보통 마감 1시간 전쯤 올라와요.</Empty>
      ) : (
        <ul className="flex flex-col gap-2.5 px-4 pb-4">
          {list.map(({ l, st, d }) => (
            <li key={l.id}>
              <Link to={`/box/${l.id}`} className={`relative grid grid-cols-[64px_1fr] gap-3 rounded-2xl border border-line p-3 hover:border-accent ${canReserve(st) ? '' : 'opacity-55'}`}>
                <Thumb category={l.category} photo={l.photo_url} />
                <div className="min-w-0">
                  <div className="truncate pr-20 text-[15px] font-bold">{l.stores?.name}</div>
                  <div className="text-xs text-muted">{l.title} · <span className="num">{distText(d)}</span></div>
                  <div className="num text-xs text-muted">픽업 {windowText(l)}</div>
                  <div className="num mt-0.5 flex items-baseline gap-1.5">
                    <s className="text-xs text-muted">{won(l.orig_price)}</s>
                    <strong className="text-base">{won(l.price)}</strong>
                    <span className="text-[13px] font-bold text-danger">{pct(l.price, l.orig_price)}%</span>
                  </div>
                </div>
                <span className="absolute top-3 right-3">
                  {st === 'pickup' ? <Badge tone="ok">{l.qty_left}개 · 지금 픽업</Badge>
                    : st === 'open' ? <Badge tone="crust">{l.qty_left}개 남음</Badge>
                      : st === 'soldout' ? <Badge tone="gray">마감</Badge> : <Badge tone="gray">판매 종료</Badge>}
                </span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
