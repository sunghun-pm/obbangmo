import { useState, type FormEvent } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Button, useToast } from '../components/ui';

export default function Login() {
  const nav = useNavigate();
  const loc = useLocation();
  const toast = useToast();
  const from = (loc.state as { from?: string } | null)?.from;
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [role, setRole] = useState<'user' | 'owner'>('user');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [nickname, setNickname] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (password.length < 8) { setError('비밀번호는 8자 이상이에요.'); return; }
    setBusy(true);
    try {
      if (mode === 'signup') {
        const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { role, nickname: nickname || null } } });
        if (error) throw error;
        if (!data.session) { toast('가입 확인 메일을 보냈어요. 메일의 링크를 누른 뒤 로그인해 주세요.'); setMode('login'); return; }
        toast(role === 'owner' ? '사장님 계정을 만들었어요. 매장을 등록해 주세요.' : '가입했어요. 근처 마감 박스를 둘러보세요.');
        nav(role === 'owner' ? '/owner' : from || '/', { replace: true });
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        const r = data.user.user_metadata?.role;
        nav(from || (r === 'owner' ? '/owner' : '/'), { replace: true });
      }
    } catch (err) {
      const m = (err as { message?: string }).message ?? '';
      setError(/Invalid login/i.test(m) ? '이메일 또는 비밀번호가 맞지 않아요.' : /already registered/i.test(m) ? '이미 가입된 이메일이에요. 로그인해 주세요.' : '잠시 후 다시 시도해 주세요.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-1 flex-col px-5 pt-8">
      <div className="font-display text-4xl text-accent">오빵뭐</div>
      <p className="mt-1 text-sm text-muted">오늘 빵 뭐 남았지? 동네 빵집 마감 박스를 할인가로.</p>
      <div className="mt-8 grid grid-cols-2 gap-1 rounded-xl border border-line p-1" role="tablist">
        {(['login', 'signup'] as const).map((m) => (
          <button key={m} type="button" role="tab" aria-selected={mode === m} onClick={() => setMode(m)}
            className={`rounded-lg py-2.5 font-semibold ${mode === m ? 'bg-accent text-accent-ink' : 'text-muted'}`}>{m === 'login' ? '로그인' : '회원가입'}</button>
        ))}
      </div>
      <form onSubmit={submit} className="mt-6 flex flex-col gap-4">
        {mode === 'signup' && (
          <fieldset className="flex flex-col gap-2">
            <legend className="mb-2 text-xs font-semibold text-muted">어떻게 쓰실 건가요?</legend>
            <div className="grid grid-cols-2 gap-2">
              {([['user', '박스 사러 왔어요', '근처 마감 박스 예약'], ['owner', '빵집 사장님이에요', '남은 빵을 박스로 판매']] as const).map(([v, t, s]) => (
                <label key={v} className={`cursor-pointer rounded-xl border p-3 ${role === v ? 'border-accent bg-accent-soft' : 'border-line'}`}>
                  <input type="radio" name="role" value={v} checked={role === v} onChange={() => setRole(v)} className="sr-only" />
                  <div className="font-semibold">{t}</div><div className="text-xs text-muted">{s}</div>
                </label>
              ))}
            </div>
          </fieldset>
        )}
        <label className="flex flex-col gap-1.5 text-xs font-semibold text-muted">이메일
          <input id="email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className="rounded-xl border border-line bg-surface-2 px-3 py-3 text-base text-ink" />
        </label>
        <label className="flex flex-col gap-1.5 text-xs font-semibold text-muted">비밀번호 (8자 이상)
          <input id="password" type="password" required autoComplete={mode === 'login' ? 'current-password' : 'new-password'} value={password} onChange={(e) => setPassword(e.target.value)} className="rounded-xl border border-line bg-surface-2 px-3 py-3 text-base text-ink" />
        </label>
        {mode === 'signup' && (
          <label className="flex flex-col gap-1.5 text-xs font-semibold text-muted">닉네임 (선택)
            <input id="nickname" maxLength={12} value={nickname} onChange={(e) => setNickname(e.target.value)} className="rounded-xl border border-line bg-surface-2 px-3 py-3 text-base text-ink" />
          </label>
        )}
        {error && <p className="text-sm text-danger" role="alert">{error}</p>}
        <Button type="submit" disabled={busy}>{busy ? '처리 중…' : mode === 'login' ? '로그인' : '가입하기'}</Button>
      </form>
    </div>
  );
}
