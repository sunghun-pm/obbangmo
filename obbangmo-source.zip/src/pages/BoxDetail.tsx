import { useCallback, useEffect, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { supabase, type Listing, type Reservation } from '../lib/supabase';
import { canReserve, distText, distanceM, listingState, pct, windowText, won } from '../lib/format';
import { errorCode, friendly } from '../lib/errors';
import { useLiveReload, useNow } from '../lib/hooks';
import { useAuth } from '../lib/auth';
import { BackBar, Button, Loading, Stepper, StickyCta, Thumb, useToast } from '../components/ui';

export default function BoxDetail() {
  const { id } = useParams();
  const nav = useNavigate();
  const loc = useLocation();
  const toast = useToast();
  const now = useNow();
  const { userId } = useAuth();
  const [l, setL] = useState<Listing | null | undefined>(undefined);
  const [qty, setQty] = useState(1);
  const [busy, setBusy] = useState(false);
  const [soldOut, setSoldOut] = useState(false);

  const load = useCallback(async () => {
    const { data } = await supabase.from('listings').select('*, stores(name,address,lat,lng)').eq('id', id!).maybeSingle();
    setL((data as Listing) ?? null);
  }, [id]);
  useEffect(() => { load(); }, [load]);
  useLiveReload(['listings'], load, { filter: `id=eq.${id}` });

  if (l === undefined) return <Loading />;
  if (l === null) return <div><BackBar to="/" label="근처 마감 박스" /><p className="p-6 text-muted">박스를 찾을 수 없어요.</p></div>;

  if (soldOut) {
    return (
      <div className="flex flex-1 flex-col">
        <BackBar to="/" label="근처 마감 박스" />
        <div className="mx-4 mt-6 rounded-2xl bg-danger-soft p-5">
          <b className="text-danger">방금 마지막 박스가 다른 분께 예약됐어요</b>
          <p className="mt-2">{l.stores?.name}의 오늘 박스가 모두 나갔어요. 결제는 진행되지 않았어요.</p>
        </div>
        <StickyCta><Link to="/" className="block rounded-2xl bg-accent py-3.5 text-center font-bold text-accent-ink">다른 박스 보러 가기</Link></StickyCta>
      </div>
    );
  }

  const st = listingState(l, now);
  const max = Math.max(1, Math.min(l.qty_left, 2));
  const q = Math.min(qty, max);
  const reason = st === 'ended' ? '오늘 판매가 끝났어요' : st === 'soldout' ? (l.closed_at && l.qty_left > 0 ? '사장님이 오늘 판매를 마감했어요' : '오늘 박스가 모두 예약됐어요') : null;

  async function reserve() {
    if (!userId) { nav('/login', { state: { from: loc.pathname } }); return; }
    setBusy(true);
    const { data, error } = await supabase.rpc('reserve', { p_listing_id: l!.id, p_qty: q });
    setBusy(false);
    if (error) {
      if (errorCode(error) === 'SOLD_OUT') { setSoldOut(true); load(); return; }
      toast(friendly(error));
      return;
    }
    nav(`/checkout/${(data as Reservation).id}`);
  }

  return (
    <div className="flex flex-1 flex-col">
      <BackBar to="/" label="근처 마감 박스" />
      <Thumb category={l.category} photo={l.photo_url} size="lg" />
      <div className="px-4 pt-4">
        <div className="text-xs text-muted">{l.stores?.name} · <span className="num">{l.stores ? distText(distanceM(l.stores.lat, l.stores.lng)) : ''}</span></div>
        <h1 className="text-[22px] font-bold tracking-tight">{l.title}</h1>
        <div className="num mt-1 flex items-baseline gap-2">
          <s className="text-sm text-muted">{won(l.orig_price)}</s>
          <strong className="text-2xl">{won(l.price)}</strong>
          <span className="font-bold text-danger">{pct(l.price, l.orig_price)}% 할인</span>
        </div>
        <dl className="mt-4 border-t border-line text-sm">
          {[
            ['픽업 시간', <span className="num">오늘 {windowText(l)}</span>],
            ['남은 수량', canReserve(st) ? <span><b className="num">{l.qty_left}</b>개 (1인 최대 2개)</span> : '—'],
            ['이런 게 들어가요', l.items_desc],
            ['알레르기', l.allergens.length ? `${l.allergens.join(', ')} 성분이 포함될 수 있어요` : '사장님이 표시한 알레르기 성분이 없어요'],
            ['위치', l.stores?.address ?? '—'],
          ].map(([k, v], i) => (
            <div key={i} className="grid grid-cols-[92px_1fr] gap-2 border-b border-line py-3">
              <dt className="text-muted">{k}</dt><dd className="min-w-0">{v}</dd>
            </div>
          ))}
        </dl>
        <p className="mt-3 rounded-xl bg-surface-2 p-3 text-sm text-muted">그날 남은 빵으로 구성하는 랜덤 박스예요. 매일 들어가는 빵이 달라요.</p>
        {canReserve(st) && (
          <div className="mt-4 flex items-center justify-between">
            <b>수량</b>
            <Stepper label="수량" value={q} min={1} max={max} onChange={setQty} />
          </div>
        )}
      </div>
      <StickyCta>
        <Button className="w-full" disabled={!!reason || busy} onClick={reserve}>
          {reason ?? (busy ? '재고 확인 중…' : `${won(l.price * q)} · 예약하기`)}
        </Button>
      </StickyCta>
    </div>
  );
}
