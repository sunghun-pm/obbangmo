import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase, type Reservation } from '../lib/supabase';
import { TICKET_LABEL, TICKET_TONE, ticketState, windowText } from '../lib/format';
import { useAuth } from '../lib/auth';
import { useLiveReload, useNow } from '../lib/hooks';
import { Empty, Loading, Thumb } from '../components/ui';

export default function Tickets() {
  const { userId, signOut } = useAuth();
  const now = useNow();
  const [rows, setRows] = useState<Reservation[] | null>(null);
  const load = useCallback(async () => {
    const { data } = await supabase.from('reservations').select('*, listings(*, stores(name,address))')
      .eq('user_id', userId!).not('status', 'in', '(held,expired)').order('created_at', { ascending: false }).limit(50);
    setRows((data as Reservation[]) ?? []);
  }, [userId]);
  useEffect(() => { load(); }, [load]);
  useLiveReload(['reservations'], load, { filter: `user_id=eq.${userId}` });

  return (
    <div>
      <header className="flex items-center justify-between px-4 pt-4 pb-3">
        <h1 className="text-xl font-bold">내 예약</h1>
        <button type="button" onClick={signOut} className="text-sm text-muted underline underline-offset-2">로그아웃</button>
      </header>
      {rows === null ? <Loading /> : rows.length === 0 ? (
        <Empty action={{ to: '/', label: '마감 박스 보기' }}>아직 예약한 박스가 없어요.</Empty>
      ) : (
        <ul className="flex flex-col gap-2.5 px-4 pb-4">
          {rows.map((r) => {
            const st = ticketState(r, now);
            const l = r.listings!;
            return (
              <li key={r.id}>
                <Link to={`/tickets/${r.id}`} className="relative grid grid-cols-[64px_1fr] gap-3 rounded-2xl border border-line p-3">
                  <Thumb category={l.category} photo={l.photo_url} />
                  <div className="min-w-0">
                    <div className="truncate pr-24 font-bold">{l.stores?.name}</div>
                    <div className="text-xs text-muted">{l.title} × {r.qty} · {r.sale_date.slice(5).replace('-', '/')}</div>
                    <div className="num text-xs text-muted">픽업 {windowText(l)} · 코드 {r.pickup_code}</div>
                  </div>
                  <span className={`absolute top-3 right-3 rounded-full px-2 py-0.5 text-[11px] font-bold ${TICKET_TONE[st]}`}>{TICKET_LABEL[st]}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
