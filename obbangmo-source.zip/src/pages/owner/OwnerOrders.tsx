import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { supabase, type Reservation } from '../../lib/supabase';
import { TICKET_LABEL, TICKET_TONE, kstToday, ticketState } from '../../lib/format';
import { friendly } from '../../lib/errors';
import { useLiveReload, useNow } from '../../lib/hooks';
import { cancelReservation } from '../../lib/payments';
import { Button, ConfirmSheet, Empty, Loading, useToast } from '../../components/ui';
import { useMyStore } from './store';

export default function OwnerOrders() {
  const { store } = useMyStore();
  const toast = useToast();
  const now = useNow();
  const [rows, setRows] = useState<Reservation[] | null>(null);
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [cancelling, setCancelling] = useState<Reservation | null>(null);
  const seen = useRef<Set<string> | null>(null);

  const load = useCallback(async () => {
    const { data } = await supabase.from('reservations').select('*, listings(*)')
      .eq('store_id', store!.id).eq('sale_date', kstToday()).in('status', ['booked', 'picked', 'no_show', 'canceled'])
      .order('created_at', { ascending: false });
    const list = (data as Reservation[]) ?? [];
    const booked = list.filter((r) => r.status === 'booked');
    if (seen.current) {
      const fresh = booked.filter((r) => !seen.current!.has(r.id));
      if (fresh.length) toast(`새 예약 ${fresh.length}건 · ${fresh[0].listings?.title} ${fresh[0].qty}개`);
    }
    seen.current = new Set(list.map((r) => r.id));
    setRows(list);
  }, [store, toast]);
  useEffect(() => { load(); }, [load]);
  useLiveReload(['reservations'], load, { filter: `store_id=eq.${store!.id}`, pollMs: 10000 });

  async function pickup(c: string) {
    if (!/^\d{4}$/.test(c)) { toast('픽업 코드는 숫자 4자리예요'); return; }
    setBusy(true);
    const { error } = await supabase.rpc('confirm_pickup', { p_code: c });
    setBusy(false);
    if (error) { toast(friendly(error)); return; }
    toast(`코드 ${c} 픽업 완료로 처리했어요`);
    setCode('');
    load();
    window.dispatchEvent(new Event('obm:orders-changed'));
  }
  async function cancel(r: Reservation) {
    setCancelling(null);
    try { await cancelReservation(r.id); toast(`코드 ${r.pickup_code} 예약을 취소했어요. 손님에게 환불돼요.`); load(); window.dispatchEvent(new Event('obm:orders-changed')); }
    catch (e) { toast(friendly(e)); }
  }

  return (
    <div>
      <header className="px-4 pt-4 pb-3">
        <div className="text-xs text-muted">{store!.name} · 사장님 모드</div>
        <h1 className="text-xl font-bold">오늘 예약자</h1>
      </header>
      <form className="mx-4 flex gap-2" onSubmit={(e: FormEvent) => { e.preventDefault(); pickup(code); }}>
        <input id="codein" inputMode="numeric" maxLength={4} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
          placeholder="픽업 코드 4자리" aria-label="픽업 코드" className="min-w-0 flex-1 rounded-xl border border-line bg-surface-2 px-4 py-3 font-mono text-lg tracking-[0.3em] placeholder:font-sans placeholder:text-base placeholder:tracking-normal" />
        <Button type="submit" className="!py-3" disabled={busy}>확인</Button>
      </form>
      {rows === null ? <Loading /> : rows.length === 0 ? (
        <Empty>아직 예약이 없어요.<br />오늘 판매를 올리면 여기에 예약자가 표시돼요.</Empty>
      ) : (
        <ul className="px-4 pt-2 pb-4">
          {rows.map((r) => {
            const st = ticketState(r, now);
            return (
              <li key={r.id} className="grid grid-cols-[1fr_auto] items-center gap-2 border-b border-line py-3">
                <div className="min-w-0">
                  <b className="font-mono">코드 {r.pickup_code}</b> <span className="text-sm text-muted">{r.listings?.title} × {r.qty}</span>
                  <div><span className={`rounded-full px-2 py-0.5 text-[11px] font-bold ${TICKET_TONE[st]}`}>{TICKET_LABEL[st]}</span></div>
                </div>
                {r.status === 'booked' && st !== 'no_show' ? (
                  <div className="flex gap-1.5">
                    <button type="button" className="rounded-lg border border-line px-3 py-2 text-sm font-semibold" onClick={() => pickup(r.pickup_code)}>픽업 완료</button>
                    <button type="button" className="rounded-lg px-2 py-2 text-sm text-muted" onClick={() => setCancelling(r)}>취소</button>
                  </div>
                ) : <span />}
              </li>
            );
          })}
        </ul>
      )}
      <ConfirmSheet open={!!cancelling} title="이 예약을 취소할까요?" body="손님에게 전액 환불돼요. 박스는 다시 예약할 수 있게 돼요."
        confirmLabel="예약 취소" danger onConfirm={() => cancelling && cancel(cancelling)} onClose={() => setCancelling(null)} />
    </div>
  );
}
