import { useEffect, useState, type ChangeEvent } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { supabase, type Product } from '../../lib/supabase';
import { ALLERGENS, CATEGORIES, WINDOWS, kstToday, timeShort, won } from '../../lib/format';
import { BackBar, Button, ConfirmSheet, Loading, Stepper, StickyCta, Thumb, useToast } from '../../components/ui';
import { useMyStore } from './store';

type Form = { title: string; category: string; orig: string; price: string; items: string; allergens: string[]; qty: number; win: number; photo: string | null };
type Errs = Partial<Record<'title' | 'orig' | 'price' | 'items', string>>;

const blank: Form = { title: '', category: '빵', orig: '', price: '', items: '', allergens: [], qty: 4, win: 1, photo: null };
const digits = (s: string) => s.replace(/\D/g, '').slice(0, 6);

export function validate(f: Form): Errs {
  const e: Errs = {};
  const o = Number(f.orig), p = Number(f.price);
  if (!f.title.trim()) e.title = '상품 이름을 입력해 주세요';
  if (!o || o < 1000) e.orig = '정가 상당 금액을 1,000원 이상으로 입력해 주세요';
  else if (!p) e.price = '판매가를 입력해 주세요';
  else if (p * 2 > o) e.price = `판매가는 정가의 50% 이하로 정해 주세요 (최대 ${won(Math.floor(o / 2 / 100) * 100)})`;
  else if (p % 100 !== 0) e.price = '판매가는 100원 단위로 입력해 주세요';
  if (!f.items.trim()) e.items = '들어갈 수 있는 품목 예시를 적어 주세요';
  return e;
}

async function shrink(file: File): Promise<Blob> {
  const url = URL.createObjectURL(file);
  const img = await new Promise<HTMLImageElement>((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
  const k = Math.min(1, 480 / Math.max(img.width, img.height));
  const c = document.createElement('canvas');
  c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
  c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height);
  URL.revokeObjectURL(url);
  return new Promise((res) => c.toBlob((b) => res(b!), 'image/jpeg', 0.82));
}

export default function ProductForm() {
  const { id } = useParams();
  const nav = useNavigate();
  const toast = useToast();
  const { store } = useMyStore();
  const [f, setF] = useState<Form | null>(id ? null : blank);
  const [errs, setErrs] = useState<Errs>({});
  const [busy, setBusy] = useState(false);
  const [onSale, setOnSale] = useState(false);
  const [confirmDel, setConfirmDel] = useState(false);
  const [photoNote, setPhotoNote] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    (async () => {
      const { data } = await supabase.from('products').select('*').eq('id', id).maybeSingle();
      const p = data as Product | null;
      if (!p) { nav('/owner/products', { replace: true }); return; }
      const w = WINDOWS.findIndex(([s, e]) => s === timeShort(p.default_start) && e === timeShort(p.default_end));
      setF({ title: p.title, category: p.category, orig: String(p.orig_price), price: String(p.price), items: p.items_desc, allergens: p.allergens, qty: p.default_qty, win: w < 0 ? 1 : w, photo: p.photo_url });
      const { data: l } = await supabase.from('listings').select('id,closed_at,pickup_end').eq('product_id', id).eq('sale_date', kstToday()).maybeSingle();
      setOnSale(!!l && !l.closed_at && new Date(l.pickup_end).getTime() > Date.now());
    })();
  }, [id, nav]);

  if (!f) return <Loading />;
  const set = (patch: Partial<Form>) => { setF({ ...f, ...patch }); setErrs({}); };
  const o = Number(f.orig), p = Number(f.price);
  const discount = o && p ? (p >= o ? '판매가가 정가보다 낮아야 해요' : `${Math.round((1 - p / o) * 100)}% 할인 · 손님에게 ${won(o - p)} 이득`) : '정가와 판매가를 넣으면 할인율이 계산돼요';

  async function onPhoto(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { toast('이미지 파일만 올릴 수 있어요'); return; }
    setPhotoNote('사진 올리는 중…');
    try {
      const blob = await shrink(file);
      const path = `${store!.id}/${crypto.randomUUID()}.jpg`;
      const { error } = await supabase.storage.from('product-photos').upload(path, blob, { contentType: 'image/jpeg' });
      if (error) throw error;
      set({ photo: supabase.storage.from('product-photos').getPublicUrl(path).data.publicUrl });
      setPhotoNote(null);
    } catch {
      setPhotoNote('사진을 올리지 못했어요. 사진 없이도 저장할 수 있어요.');
    }
  }

  async function save() {
    const e = validate(f!);
    setErrs(e);
    if (Object.keys(e).length) { toast('입력 내용을 확인해 주세요'); return; }
    const [s, en] = WINDOWS[f!.win];
    const row = { store_id: store!.id, title: f!.title.trim(), category: f!.category, orig_price: o, price: p, items_desc: f!.items.trim(), allergens: f!.allergens, default_qty: f!.qty, default_start: s, default_end: en, photo_url: f!.photo };
    setBusy(true);
    const { error } = id ? await supabase.from('products').update(row).eq('id', id) : await supabase.from('products').insert(row);
    setBusy(false);
    if (error) { toast('저장하지 못했어요. 잠시 후 다시 시도해 주세요.'); return; }
    toast(id ? '상품을 수정했어요' : "상품을 등록했어요. '오늘 판매' 탭에서 바로 올릴 수 있어요.");
    nav(id ? '/owner/products' : '/owner');
  }

  async function remove() {
    setConfirmDel(false);
    if (onSale) { toast('판매 중인 상품은 먼저 오늘 판매를 마감해 주세요'); return; }
    const { error } = await supabase.from('products').update({ deleted_at: new Date().toISOString() }).eq('id', id!);
    if (error) { toast('삭제하지 못했어요'); return; }
    toast('상품을 삭제했어요');
    nav('/owner/products');
  }

  const input = 'w-full rounded-xl border bg-surface-2 px-3 py-3 text-base text-ink';
  const chip = (on: boolean) => `rounded-lg border px-3 py-2 text-[13px] ${on ? 'border-accent bg-accent-soft text-accent' : 'border-line'}`;

  return (
    <div className="flex flex-1 flex-col">
      <BackBar to="/owner/products" label="박스 상품" />
      <div className="flex flex-col gap-4 px-4 pb-2">
        <h1 className="text-[22px] font-bold">{id ? '상품 수정' : '새 박스 상품 등록'}</h1>
        {onSale && <p className="rounded-xl bg-surface-2 p-3 text-sm text-muted">지금 판매 중인 상품이에요. 수정한 내용은 다음 판매부터 적용돼요.</p>}
        <div className="flex flex-col gap-1.5"><span className="text-xs font-semibold text-muted">대표 사진 (선택)</span>
          <div className="flex items-center gap-3">
            <div className="h-[72px] w-[72px]"><Thumb category={f.category} photo={f.photo} /></div>
            <div className="flex flex-col items-start gap-1">
              <label className="cursor-pointer rounded-lg border border-line px-3 py-2 text-sm font-semibold">{f.photo ? '사진 바꾸기' : '사진 올리기'}
                <input id="photo" type="file" accept="image/*" className="sr-only" onChange={onPhoto} /></label>
              <span className={`text-xs ${photoNote ? 'text-danger' : 'text-muted'}`}>{photoNote ?? '사진이 없으면 종류 글자로 보여요'}</span>
            </div>
          </div>
        </div>
        <label className="flex flex-col gap-1.5 text-xs font-semibold text-muted">상품 이름
          <input id="title" maxLength={20} value={f.title} onChange={(e) => set({ title: e.target.value })} placeholder="예: 빵 마감박스" className={`${input} ${errs.title ? 'border-danger' : 'border-line'}`} />
          {errs.title && <span className="font-normal text-danger">{errs.title}</span>}
        </label>
        <div className="flex flex-col gap-1.5"><span className="text-xs font-semibold text-muted">종류</span>
          <div className="flex gap-1.5">{CATEGORIES.map((c) => <button key={c} type="button" aria-pressed={f.category === c} onClick={() => set({ category: c })} className={chip(f.category === c)}>{c}</button>)}</div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <label className="flex min-w-0 flex-col gap-1.5 text-xs font-semibold text-muted">정가 상당 금액
            <input id="orig" inputMode="numeric" value={f.orig} onChange={(e) => set({ orig: digits(e.target.value) })} placeholder="15000" className={`num ${input} ${errs.orig ? 'border-danger' : 'border-line'}`} /></label>
          <label className="flex min-w-0 flex-col gap-1.5 text-xs font-semibold text-muted">판매가
            <input id="price" inputMode="numeric" value={f.price} onChange={(e) => set({ price: digits(e.target.value) })} placeholder="4900" className={`num ${input} ${errs.price ? 'border-danger' : 'border-line'}`} /></label>
        </div>
        <span id="discount" className={`-mt-2 text-xs ${errs.orig || errs.price ? 'text-danger' : 'text-muted'}`}>{errs.orig || errs.price || discount}</span>
        <label className="flex flex-col gap-1.5 text-xs font-semibold text-muted">이런 게 들어가요
          <textarea id="items" maxLength={80} rows={3} value={f.items} onChange={(e) => set({ items: e.target.value })} placeholder="예: 소금빵, 바게트, 크루아상 등 그날 남은 빵 3~5개" className={`${input} ${errs.items ? 'border-danger' : 'border-line'}`} />
          <span className={`font-normal ${errs.items ? 'text-danger' : ''}`}>{errs.items || '정확한 품목 대신 들어갈 수 있는 예시와 개수 범위를 적어 주세요'}</span>
        </label>
        <div className="flex flex-col gap-1.5"><span className="text-xs font-semibold text-muted">알레르기 유발 성분 (포함될 수 있는 것 모두)</span>
          <div className="flex flex-wrap gap-1.5">{ALLERGENS.map((a) => {
            const on = f.allergens.includes(a);
            return <button key={a} type="button" aria-pressed={on} onClick={() => set({ allergens: on ? f.allergens.filter((x) => x !== a) : [...f.allergens, a] })} className={chip(on)}>{a}</button>;
          })}</div>
        </div>
        <div className="flex items-center justify-between"><span className="text-xs font-semibold text-muted">기본 수량 (1인 최대 2개)</span>
          <Stepper label="기본 수량" value={f.qty} min={1} max={20} onChange={(v) => set({ qty: v })} /></div>
        <div className="flex flex-col gap-1.5"><span className="text-xs font-semibold text-muted">기본 픽업 시간</span>
          <div className="flex flex-wrap gap-1.5">{WINDOWS.map(([s, e], i) => <button key={s} type="button" aria-pressed={f.win === i} onClick={() => set({ win: i })} className={`font-mono ${chip(f.win === i)}`}>{s}–{e}</button>)}</div>
        </div>
        {id && <Button variant="danger" onClick={() => setConfirmDel(true)}>이 상품 삭제</Button>}
      </div>
      <StickyCta><Button className="w-full" disabled={busy} onClick={save}>{busy ? '저장 중…' : id ? '수정 내용 저장' : '상품 등록하기'}</Button></StickyCta>
      <ConfirmSheet open={confirmDel} title="이 상품을 삭제할까요?" body="지난 판매 기록은 남고, 상품 목록과 오늘 판매 탭에서만 사라져요." confirmLabel="삭제" danger onConfirm={remove} onClose={() => setConfirmDel(false)} />
    </div>
  );
}
