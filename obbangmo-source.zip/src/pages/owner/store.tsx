import { createContext, useCallback, useContext, useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { supabase, type Store } from '../../lib/supabase';
import { useAuth } from '../../lib/auth';
import { ORIGIN } from '../../lib/format';
import { Button, Loading, useToast } from '../../components/ui';

type Ctx = { store: Store | null; reload: () => Promise<void> };
const StoreCtx = createContext<Ctx>({ store: null, reload: async () => {} });
export const useMyStore = () => useContext(StoreCtx);

/** 사장님 영역: 내 매장이 없으면 매장 등록 화면을 먼저 보여준다 */
export function MyStoreProvider({ children }: { children: ReactNode }) {
  const { userId } = useAuth();
  const [store, setStore] = useState<Store | null | undefined>(undefined);
  const reload = useCallback(async () => {
    const { data } = await supabase.from('stores').select('*').eq('owner_id', userId!).limit(1).maybeSingle();
    setStore((data as Store) ?? null);
  }, [userId]);
  useEffect(() => { reload(); }, [reload]);
  if (store === undefined) return <Loading />;
  if (store === null) return <StoreSetup onDone={reload} />;
  return <StoreCtx.Provider value={{ store, reload }}>{children}</StoreCtx.Provider>;
}

function StoreSetup({ onDone }: { onDone: () => Promise<void> }) {
  const { userId, signOut } = useAuth();
  const toast = useToast();
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [lat, setLat] = useState(String(ORIGIN.lat));
  const [lng, setLng] = useState(String(ORIGIN.lng));
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!name.trim()) { setErr('매장 이름을 입력해 주세요'); return; }
    const la = Number(lat), ln = Number(lng);
    if (!Number.isFinite(la) || !Number.isFinite(ln)) { setErr('위도·경도를 숫자로 입력해 주세요'); return; }
    setBusy(true);
    const { error } = await supabase.from('stores').insert({ owner_id: userId, name: name.trim(), address: address.trim() || null, lat: la, lng: ln });
    setBusy(false);
    if (error) { setErr('매장을 저장하지 못했어요. 잠시 후 다시 시도해 주세요.'); return; }
    toast('매장을 등록했어요. 이제 박스 상품을 등록해 보세요.');
    await onDone();
  }

  return (
    <div className="mx-auto flex min-h-full max-w-[430px] flex-col bg-surface px-5 pt-8 pb-8">
      <div className="text-xs text-muted">사장님 모드</div>
      <h1 className="text-2xl font-bold">매장 등록</h1>
      <p className="mt-1 text-sm text-muted">손님 앱의 지도와 목록에 이 정보가 보여요.</p>
      <form onSubmit={submit} className="mt-6 flex flex-col gap-4">
        <label className="flex flex-col gap-1.5 text-xs font-semibold text-muted">매장 이름
          <input id="store-name" maxLength={30} value={name} onChange={(e) => setName(e.target.value)} placeholder="예: 소금결 베이커리" className="rounded-xl border border-line bg-surface-2 px-3 py-3 text-base text-ink" />
        </label>
        <label className="flex flex-col gap-1.5 text-xs font-semibold text-muted">주소
          <input id="store-address" maxLength={80} value={address} onChange={(e) => setAddress(e.target.value)} placeholder="예: 서울 마포구 망원로 00" className="rounded-xl border border-line bg-surface-2 px-3 py-3 text-base text-ink" />
        </label>
        <div className="grid grid-cols-2 gap-2">
          <label className="flex min-w-0 flex-col gap-1.5 text-xs font-semibold text-muted">위도
            <input id="store-lat" inputMode="decimal" value={lat} onChange={(e) => setLat(e.target.value)} className="num rounded-xl border border-line bg-surface-2 px-3 py-3 text-base text-ink" />
          </label>
          <label className="flex min-w-0 flex-col gap-1.5 text-xs font-semibold text-muted">경도
            <input id="store-lng" inputMode="decimal" value={lng} onChange={(e) => setLng(e.target.value)} className="num rounded-xl border border-line bg-surface-2 px-3 py-3 text-base text-ink" />
          </label>
        </div>
        <p className="-mt-2 text-xs text-muted">기본값은 망원역이에요. 지도 앱에서 매장 좌표를 복사해 넣을 수 있어요.</p>
        {err && <p className="text-sm text-danger" role="alert">{err}</p>}
        <Button type="submit" disabled={busy}>{busy ? '저장 중…' : '매장 등록하기'}</Button>
        <button type="button" onClick={signOut} className="text-sm text-muted underline underline-offset-2">다른 계정으로 로그인</button>
      </form>
    </div>
  );
}
