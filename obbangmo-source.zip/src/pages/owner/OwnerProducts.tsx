import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase, type Product } from '../../lib/supabase';
import { pct, timeShort, won } from '../../lib/format';
import { Loading, Thumb } from '../../components/ui';
import { useMyStore } from './store';

export default function OwnerProducts() {
  const { store } = useMyStore();
  const [rows, setRows] = useState<Product[] | null>(null);
  useEffect(() => {
    supabase.from('products').select('*').eq('store_id', store!.id).is('deleted_at', null).order('created_at')
      .then(({ data }) => setRows((data as Product[]) ?? []));
  }, [store]);
  if (rows === null) return <Loading />;
  return (
    <div>
      <header className="px-4 pt-4 pb-1">
        <div className="text-xs text-muted">{store!.name} · 사장님 모드</div>
        <h1 className="text-xl font-bold">박스 상품</h1>
        <p className="mt-1 text-sm text-muted">한 번 등록해 두면 매일 '오늘 판매' 탭에서 버튼 하나로 올릴 수 있어요.</p>
      </header>
      <div className="flex flex-col gap-2.5 p-4">
        {rows.map((p) => (
          <div key={p.id} className="grid grid-cols-[56px_1fr_auto] items-center gap-3 rounded-2xl border border-line p-3">
            <Thumb category={p.category} photo={p.photo_url} size="sm" />
            <div className="min-w-0">
              <b>{p.title}</b> <span className="rounded-md bg-surface-2 px-1.5 text-[11px] font-bold text-muted">{p.category}</span>
              <div className="num text-xs text-muted">{won(p.price)} <s>{won(p.orig_price)}</s> · {pct(p.price, p.orig_price)}% 할인</div>
              <div className="num text-xs text-muted">기본 {p.default_qty}개 · 픽업 {timeShort(p.default_start)}–{timeShort(p.default_end)}</div>
            </div>
            <Link to={`/owner/products/${p.id}`} className="rounded-lg border border-line px-3 py-2 text-sm font-semibold">수정</Link>
          </div>
        ))}
        <Link to="/owner/products/new" className="rounded-2xl border-[1.5px] border-dashed border-line py-3.5 text-center font-semibold text-accent">+ 새 박스 상품 등록</Link>
      </div>
    </div>
  );
}
