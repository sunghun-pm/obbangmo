import { useCallback, useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase, type Listing, type Product } from '../../lib/supabase';
import { WINDOWS, kstToday, listingState, timeShort, windowText, won } from '../../lib/format';
import { friendly } from '../../lib/errors';
import { useLiveReload, useNow } from '../../lib/hooks';
import { useAuth } from '../../lib/auth';
import { Button, ConfirmSheet, Loading, Stepper, Thumb, useToast } from '../../components/ui';
import { useMyStore } from './store';

type Cfg = { qty: number; start: string; end: string };

export default function OwnerToday() {
  const { store } = useMyStore();
  const { signOut } = useAuth();
  const toast = useToast();
  const now = useNow();
  const t0 = useRef(Date.now());
  const [products, setProducts] = useState<Product[] | null>(null);
  const [listings, setListings] = useState<Listing[]>([]);
  const [sold, setSold] = useState({ qty: 0, amount: 0 });
  const [open, setOpen] = useState<string | null>(null);
  const [cfg, setCfg] = useState<Record<string, Cfg>>({});
  const [busy, setBusy] = useState<string | null>(null);
  const [closing, setClosing] = useState<Listing | null>(null);

  const load = useCallback(async () => {
    const today = kstToday();
    const [p, l, r] = await Promise.all([
      supabase.from('products').select('*').eq('store_id', store!.id).is('deleted_at', null).order('created_at'),
      supabase.from('listings').select('*').eq('store_id', store!.id).eq('sale_date', today),
      supabase.from('reservations').select('qty,amount').eq('store_id', store!.id).eq('sale_date', today).in('status', ['booked', 'picked', 'no_show']),
    ]);
    setProducts((p.data as Product[]) ?? []);
    setListings((l.data as Listing[]) ?? []);
    const rs = (r.data ?? []) as { qty: number; amount: number }[];
    setSold({ qty: rs.reduce((a, x) => a + x.qty, 0), amount: rs.reduce((a, x) => a + x.amount, 0) });
  }, [store]);
  useEffect(() => { load(); }, [load]);
  useLiveReload(['listings', 'reservations'], load, { filter: `store_id=eq.${store!.id}` });

  const cfgOf = (p: Product): Cfg => cfg[p.id] ?? { qty: p.default_qty, start: timeShort(p.default_start), end: timeShort(p.default_end) };

  async function post(p: Product) {
    const c = cfgOf(p);
    setBusy(p.id);
    const { error } = await supabase.rpc('open_listing', { p_product_id: p.id, p_qty: c.qty, p_start: c.start, p_end: c.end });
    setBusy(null);
    if (error) { toast(friendly(error)); return; }
    const sec = Math.max(1, Math.round((Date.now() - t0.current) / 1000));
    toast(`${p.title} ${c.qty}개를 올렸어요${sec < 120 ? ` · ${sec}초 걸렸어요` : ''}`);
    setOpen(null);
    load();
  }
  async function adjust(l: Listing, d: number) {
    const { error } = await supabase.rpc('adjust_listing_qty', { p_listing_id: l.id, p_delta: d });
    if (error) toast(friendly(error)); else load();
  }
  async function close(l: Listing) {
    setClosing(null);
    const { error } = await supabase.rpc('close_listing', { p_listing_id: l.id });
    if (error) toast(friendly(error)); else { toast('오늘 판매를 마감했어요'); load(); }
  }

  if (products === null) return <Loading />;
  const posted = listings.reduce((a, l) => a + l.qty_total, 0);
  const left = listings.filter((l) => !l.closed_at && listingState(l, now) !== 'ended').reduce((a, l) => a + l.qty_left, 0);
  const tooLate = (end: string) => now > new Date(`${kstToday()}T${end}:00+09:00`).getTime();

  return (
    <div>
      <header className="flex items-end justify-between px-4 pt-4 pb-3">
        <div><div className="text-xs text-muted">{store!.name} · 사장님 모드</div><h1 className="text-xl font-bold">오늘 판매</h1></div>
        <button type="button" onClick={signOut} className="text-sm text-muted underline underline-offset-2">로그아웃</button>
      </header>
      <div className="num mx-4 grid grid-cols-4 overflow-hidden rounded-2xl border border-line text-center">
        {[['올린 박스', posted], ['예약', sold.qty], ['남은 박스', left], ['판매액(만원)', (sold.amount / 10000).toFixed(1)]].map(([k, v], i) => (
          <div key={i} className={`py-2.5 ${i ? 'border-l border-line' : ''}`}><b className="block font-mono text-lg">{v}</b><span className="text-[11px] text-muted">{k}</span></div>
        ))}
      </div>

      {products.length === 0 ? (
        <div className="m-4 flex flex-col gap-3 rounded-2xl border border-line p-4">
          <h2 className="font-bold">등록된 상품이 없어요</h2>
          <p className="text-sm text-muted">박스 상품을 한 번 등록해 두면, 매일 버튼 하나로 오늘 판매를 올릴 수 있어요.</p>
          <Link to="/owner/products/new" className="rounded-2xl bg-accent py-3 text-center font-bold text-accent-ink">상품 등록하기</Link>
        </div>
      ) : (
        <div className="flex flex-col gap-2.5 p-4">
          <div className="text-[11px] font-semibold tracking-wider text-muted">오늘 판매할 박스</div>
          {products.map((p) => {
            const l = listings.find((x) => x.product_id === p.id);
            const c = cfgOf(p);
            if (l) {
              const st = listingState(l, now);
              const label = st === 'ended' ? ['판매 종료', 'bg-muted'] : l.closed_at || l.qty_left === 0 ? [l.closed_at ? '판매 마감' : '완판', 'bg-muted'] : st === 'pickup' ? ['픽업 시간', 'bg-ok'] : ['판매 중', 'bg-ok'];
              const active = st !== 'ended' && !l.closed_at;
              return (
                <div key={p.id} className="grid grid-cols-[56px_1fr] items-center gap-3 rounded-2xl border border-line p-3">
                  <Thumb category={p.category} photo={p.photo_url} size="sm" />
                  <div className="min-w-0">
                    <b>{p.title}</b>
                    <div className="flex items-center gap-1.5 text-[13px] font-semibold"><span className={`h-2 w-2 rounded-full ${label[1]}`} />{label[0]}
                      <span className="num font-normal text-muted">· 남은 {l.qty_left}개 · 픽업 {windowText(l)}</span></div>
                  </div>
                  {active && (
                    <div className="col-span-2 flex flex-wrap items-center gap-2">
                      <Stepper label="남은 수량" value={l.qty_left} min={0} max={40} onChange={(v) => adjust(l, v - l.qty_left)} />
                      <Button variant="danger" className="!px-3 !py-2.5 text-sm" onClick={() => setClosing(l)}>판매 마감</Button>
                    </div>
                  )}
                </div>
              );
            }
            const late = tooLate(c.end);
            return (
              <div key={p.id} className="grid grid-cols-[56px_1fr] items-center gap-3 rounded-2xl border border-line p-3">
                <Thumb category={p.category} photo={p.photo_url} size="sm" />
                <div className="min-w-0">
                  <b>{p.title}</b>
                  <div className="num text-xs text-muted">{won(p.price)} <s>{won(p.orig_price)}</s></div>
                  <div className="num text-xs text-muted">{c.qty}개 · 픽업 {c.start}–{c.end}</div>
                </div>
                {late ? <p className="col-span-2 text-sm text-muted">오늘 판매 시간이 지났어요. 조건을 바꿔 늦은 시간으로 올릴 수 있어요.</p> : null}
                <div className="col-span-2 grid grid-cols-2 gap-2">
                  <Button className="!py-2.5 text-sm" disabled={busy === p.id || late} onClick={() => post(p)}>{busy === p.id ? '올리는 중…' : '오늘 올리기'}</Button>
                  <Button variant="ghost" className="!py-2.5 text-sm" aria-expanded={open === p.id} onClick={() => setOpen(open === p.id ? null : p.id)}>{open === p.id ? '접기' : '조건 바꾸기'}</Button>
                </div>
                {open === p.id && (
                  <div className="col-span-2 flex flex-col gap-3 border-t border-line pt-3">
                    <div className="flex items-center justify-between"><span className="text-xs font-semibold text-muted">오늘 수량</span>
                      <Stepper label="오늘 수량" value={c.qty} min={1} max={20} onChange={(v) => setCfg({ ...cfg, [p.id]: { ...c, qty: v } })} /></div>
                    <div className="flex flex-col gap-1.5"><span className="text-xs font-semibold text-muted">오늘 픽업 시간</span>
                      <div className="flex flex-wrap gap-1.5">
                        {WINDOWS.map(([s, e]) => (
                          <button key={s} type="button" aria-pressed={c.start === s && c.end === e} onClick={() => setCfg({ ...cfg, [p.id]: { ...c, start: s, end: e } })}
                            className={`rounded-lg border px-3 py-2 font-mono text-[13px] ${c.start === s && c.end === e ? 'border-accent bg-accent-soft text-accent' : 'border-line'}`}>{s}–{e}</button>
                        ))}
                      </div></div>
                  </div>
                )}
              </div>
            );
          })}
          <Link to="/owner/products/new" className="rounded-2xl border-[1.5px] border-dashed border-line py-3.5 text-center font-semibold text-accent">+ 새 박스 상품 등록</Link>
        </div>
      )}
      <ConfirmSheet open={!!closing} title="오늘 판매를 마감할까요?" body="이미 들어온 예약은 유지돼요. 손님 화면에서는 바로 예약할 수 없게 돼요."
        confirmLabel="판매 마감" danger onConfirm={() => closing && close(closing)} onClose={() => setClosing(null)} />
    </div>
  );
}
