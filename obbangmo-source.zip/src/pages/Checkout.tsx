import { useEffect, useRef, useState } from 'react';
import { Navigate, useNavigate, useParams } from 'react-router-dom';
import { loadTossPayments, type TossPaymentsWidgets } from '@tosspayments/tosspayments-sdk';
import { supabase, type Reservation } from '../lib/supabase';
import { windowText, won } from '../lib/format';
import { friendly } from '../lib/errors';
import { useNow } from '../lib/hooks';
import { useAuth } from '../lib/auth';
import { TOSS_CLIENT_KEY, confirmPayment } from '../lib/payments';
import { BackBar, Button, Loading, StickyCta, useToast } from '../components/ui';

export default function Checkout() {
  const { reservationId } = useParams();
  const nav = useNavigate();
  const toast = useToast();
  const now = useNow(1000);
  const { userId, session } = useAuth();
  const [r, setR] = useState<Reservation | null | undefined>(undefined);
  const [agreed, setAgreed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [widgetReady, setWidgetReady] = useState(false);
  const widgets = useRef<TossPaymentsWidgets | null>(null);

  useEffect(() => {
    supabase.from('reservations').select('*, listings(*, stores(name,address))').eq('id', reservationId!).maybeSingle()
      .then(({ data }) => setR((data as Reservation) ?? null));
  }, [reservationId]);

  // 토스 결제위젯 v2 (클라이언트 키가 있을 때만)
  useEffect(() => {
    if (!TOSS_CLIENT_KEY || !r || r.status !== 'held' || !userId) return;
    let cancelled = false;
    (async () => {
      try {
        const toss = await loadTossPayments(TOSS_CLIENT_KEY);
        const w = toss.widgets({ customerKey: userId });
        await w.setAmount({ currency: 'KRW', value: r.amount });
        await Promise.all([
          w.renderPaymentMethods({ selector: '#payment-method', variantKey: 'DEFAULT' }),
          w.renderAgreement({ selector: '#agreement', variantKey: 'AGREEMENT' }),
        ]);
        if (!cancelled) { widgets.current = w; setWidgetReady(true); }
      } catch {
        if (!cancelled) toast('결제 수단을 불러오지 못했어요. 새로고침해 주세요.');
      }
    })();
    return () => { cancelled = true; };
  }, [r?.id, r?.status, r?.amount, userId, toast]);

  if (r === undefined) return <Loading />;
  if (r === null) return <div><BackBar label="뒤로" /><p className="p-6 text-muted">예약을 찾을 수 없어요.</p></div>;
  if (r.status === 'booked' || r.status === 'picked') return <Navigate to={`/tickets/${r.id}`} replace />;

  const l = r.listings!;
  const left = r.hold_expires_at ? new Date(r.hold_expires_at).getTime() - now : 0;
  const expired = r.status !== 'held' || left <= 0;
  const mmss = `${Math.floor(Math.max(0, left) / 60000)}:${String(Math.floor((Math.max(0, left) % 60000) / 1000)).padStart(2, '0')}`;

  async function pay() {
    if (!r) return;
    setBusy(true);
    try {
      if (TOSS_CLIENT_KEY && widgets.current) {
        const origin = window.location.origin;
        await widgets.current.requestPayment({
          orderId: r.order_id,
          orderName: `${l.stores?.name ?? ''} ${l.title}`.trim().slice(0, 100),
          successUrl: `${origin}/pay/success`,
          failUrl: `${origin}/pay/fail?listing=${l.id}`,
          customerEmail: session?.user.email,
        });
      } else {
        const res = await confirmPayment({ orderId: r.order_id, amount: r.amount, demo: true });
        toast('예약했어요. 픽업 코드를 확인하세요.');
        nav(`/tickets/${res.reservationId}`, { replace: true });
      }
    } catch (e) {
      toast(friendly(e, '결제를 완료하지 못했어요. 다시 시도해 주세요.'));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-1 flex-col">
      <BackBar to={`/box/${l.id}`} label="박스 정보" />
      <div className="px-4">
        <h1 className="text-[22px] font-bold">예약 확인</h1>
        <dl className="mt-3 border-t border-line text-sm">
          {[
            ['매장', l.stores?.name],
            ['상품', <span>{l.title} × <span className="num">{r.qty}</span></span>],
            ['픽업', <span className="num">오늘 {windowText(l)}</span>],
            ['결제 금액', <span className="num"><b className="text-lg">{won(r.amount)}</b> <s className="text-muted">{won(l.orig_price * r.qty)}</s></span>],
          ].map(([k, v], i) => (
            <div key={i} className="grid grid-cols-[84px_1fr] gap-2 border-b border-line py-3"><dt className="text-muted">{k}</dt><dd>{v}</dd></div>
          ))}
        </dl>
        <p className={`num mt-3 rounded-xl px-3 py-2 text-sm font-semibold ${expired ? 'bg-danger-soft text-danger' : 'bg-accent-soft text-accent'}`}>
          {expired ? '선점 시간이 지났어요. 다시 예약해 주세요.' : `선점 남은 시간 ${mmss} · 이 시간 안에 결제하면 박스가 확정돼요`}
        </p>
        {TOSS_CLIENT_KEY ? (
          <div className="mt-3">
            <div id="payment-method" />
            <div id="agreement" />
          </div>
        ) : (
          <p className="mt-3 rounded-xl bg-surface-2 p-3 text-sm text-muted">토스페이먼츠 키가 설정되지 않아 데모 결제로 진행해요. 실제 결제는 일어나지 않아요.</p>
        )}
        <label className="mt-4 flex items-start gap-2.5 text-sm">
          <input id="agree" type="checkbox" className="mt-0.5 h-[18px] w-[18px] accent-[var(--accent)]" checked={agreed} onChange={(e) => setAgreed(e.target.checked)} />
          <span>랜덤 구성이라 내용물은 교환할 수 없어요. 픽업 시간이 지나면 환불되지 않아요. 픽업 시작 전까지는 예약을 취소할 수 있어요.</span>
        </label>
      </div>
      <StickyCta>
        <Button className="w-full" onClick={pay} disabled={!agreed || expired || busy || (!!TOSS_CLIENT_KEY && !widgetReady)}>
          {busy ? '결제 확인 중…' : TOSS_CLIENT_KEY ? `${won(r.amount)} 결제하기` : `${won(r.amount)} 데모 결제하기`}
        </Button>
      </StickyCta>
    </div>
  );
}
