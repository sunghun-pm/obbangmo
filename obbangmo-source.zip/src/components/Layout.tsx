import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../lib/auth';
import type { ReactNode } from 'react';

const Icon = {
  pin: <path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z M12 12a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z" />,
  ticket: <path d="M4 7h16v3a2 2 0 0 0 0 4v3H4v-3a2 2 0 0 0 0-4z M10 7v10" />,
  box: <path d="M4 8l8-4 8 4v8l-8 4-8-4z M4 8l8 4 8-4 M12 12v8" />,
  tag: <path d="M3 12V4h8l10 10-8 8z M7.5 8.5h.01" />,
  list: <path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01" />,
};

function Tab({ to, label, icon, badge, end }: { to: string; label: string; icon: ReactNode; badge?: number; end?: boolean }) {
  return (
    <NavLink to={to} end={end}
      className={({ isActive }) => `relative flex flex-col items-center gap-0.5 pt-2.5 pb-1.5 text-xs font-semibold ${isActive ? 'text-accent' : 'text-muted'}`}>
      <svg viewBox="0 0 24 24" className="h-[22px] w-[22px]" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{icon}</svg>
      {label}
      {badge ? <span className="num absolute top-1.5 left-[calc(50%+6px)] min-w-[18px] rounded-full bg-danger px-1 text-[11px] leading-[18px] text-white">{badge}</span> : null}
    </NavLink>
  );
}

export function TestBanner() {
  return <div className="bg-accent-soft px-4 py-1.5 text-center text-[12px] font-semibold text-accent">테스트 결제 · 실제로 돈이 나가지 않아요</div>;
}

export function AppShell({ ownerBadge = 0 }: { ownerBadge?: number }) {
  const { pathname } = useLocation();
  const { role } = useAuth();
  const ownerArea = pathname.startsWith('/owner');
  return (
    <div className="mx-auto flex min-h-full max-w-[430px] flex-col bg-surface shadow-[0_0_0_1px_var(--line)]">
      <TestBanner />
      <main className="flex flex-1 flex-col pb-[calc(64px+env(safe-area-inset-bottom))]">
        <Outlet />
      </main>
      <nav className={`fixed inset-x-0 bottom-0 z-30 mx-auto grid max-w-[430px] border-t border-line bg-surface pb-[env(safe-area-inset-bottom)] ${ownerArea ? 'grid-cols-3' : 'grid-cols-2'}`}>
        {ownerArea ? (
          <>
            <Tab to="/owner" end label="오늘 판매" icon={Icon.box} />
            <Tab to="/owner/products" label="상품" icon={Icon.tag} />
            <Tab to="/owner/orders" label="예약자" icon={Icon.list} badge={ownerBadge} />
          </>
        ) : (
          <>
            <Tab to="/" end label="근처 박스" icon={Icon.pin} />
            <Tab to={role === 'owner' ? '/owner' : '/tickets'} label={role === 'owner' ? '사장님' : '내 예약'} icon={role === 'owner' ? Icon.box : Icon.ticket} />
          </>
        )}
      </nav>
    </div>
  );
}
