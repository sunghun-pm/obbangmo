import { createContext, useCallback, useContext, useState, type ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';

/* ---------- 토스트 ---------- */
const ToastCtx = createContext<(msg: string) => void>(() => {});
export function ToastProvider({ children }: { children: ReactNode }) {
  const [msg, setMsg] = useState<string | null>(null);
  const [timer, setTimer] = useState<number | undefined>();
  const show = useCallback((m: string) => {
    setMsg(m);
    window.clearTimeout(timer);
    setTimer(window.setTimeout(() => setMsg(null), 2800));
  }, [timer]);
  return (
    <ToastCtx.Provider value={show}>
      {children}
      <div role="status" aria-live="polite"
        className={`pointer-events-none fixed inset-x-0 bottom-24 z-50 mx-auto max-w-[400px] px-4 transition ${msg ? 'translate-y-0 opacity-100' : 'translate-y-2 opacity-0'}`}>
        {msg && <div className="rounded-xl bg-ink px-4 py-3 text-sm font-medium text-surface shadow-lg">{msg}</div>}
      </div>
    </ToastCtx.Provider>
  );
}
export const useToast = () => useContext(ToastCtx);

/* ---------- 기본 조각 ---------- */
export function Thumb({ category, photo, size = 'md' }: { category: string; photo?: string | null; size?: 'md' | 'sm' | 'lg' }) {
  const cls = size === 'lg' ? 'h-44 w-full rounded-none text-6xl' : size === 'sm' ? 'h-14 w-14 rounded-xl text-xl' : 'h-16 w-16 rounded-xl text-2xl';
  return (
    <div className={`grid shrink-0 place-items-center overflow-hidden bg-crust-soft font-display text-crust ${cls}`}>
      {photo ? <img src={photo} alt="" className="h-full w-full object-cover" /> : category.slice(0, 1)}
    </div>
  );
}

export function Stepper({ value, min, max, onChange, label }: { value: number; min: number; max: number; onChange: (v: number) => void; label: string }) {
  return (
    <div className="inline-flex items-center overflow-hidden rounded-xl border border-line" role="group" aria-label={label}>
      <button type="button" className="h-10 w-10 text-lg font-semibold disabled:text-line" disabled={value <= min} onClick={() => onChange(value - 1)} aria-label={`${label} 줄이기`}>−</button>
      <output className="num min-w-10 text-center font-mono font-semibold">{value}</output>
      <button type="button" className="h-10 w-10 text-lg font-semibold disabled:text-line" disabled={value >= max} onClick={() => onChange(value + 1)} aria-label={`${label} 늘리기`}>+</button>
    </div>
  );
}

export function Button({ children, variant = 'primary', className = '', ...rest }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'ghost' | 'danger' }) {
  const v = variant === 'primary'
    ? 'bg-accent text-accent-ink disabled:bg-surface-2 disabled:text-muted'
    : variant === 'danger'
      ? 'border border-line bg-surface text-danger'
      : 'border border-line bg-surface text-ink';
  return <button {...rest} className={`rounded-2xl px-4 py-3.5 text-[15px] font-bold ${v} ${className}`}>{children}</button>;
}

export function StickyCta({ children }: { children: ReactNode }) {
  return <div className="sticky bottom-0 mt-auto bg-gradient-to-b from-transparent to-surface to-30% px-4 pt-6 pb-4">{children}</div>;
}

export function BackBar({ to, label }: { to?: string; label: string }) {
  const nav = useNavigate();
  return (
    <button type="button" onClick={() => (to ? nav(to) : nav(-1))} className="flex items-center gap-1.5 px-3 py-2.5 font-semibold">
      <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 18l-6-6 6-6" /></svg>
      {label}
    </button>
  );
}

export function Badge({ tone, children }: { tone: 'crust' | 'ok' | 'gray' | 'accent' | 'danger'; children: ReactNode }) {
  const t = {
    crust: 'bg-crust-soft text-crust', ok: 'bg-ok-soft text-ok', gray: 'bg-surface-2 text-muted',
    accent: 'bg-accent-soft text-accent', danger: 'bg-danger-soft text-danger',
  }[tone];
  return <span className={`inline-block rounded-full px-2 py-0.5 text-[11px] font-bold whitespace-nowrap ${t}`}>{children}</span>;
}

/** 페이지 안 확인 시트 (브라우저 confirm 대신) */
export function ConfirmSheet({ open, title, body, confirmLabel, danger, onConfirm, onClose }: {
  open: boolean; title: string; body: string; confirmLabel: string; danger?: boolean; onConfirm: () => void; onClose: () => void;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-black/40" onClick={onClose}>
      <div role="dialog" aria-modal="true" aria-label={title} className="w-full max-w-[430px] rounded-t-3xl bg-surface p-5 pb-6" onClick={(e) => e.stopPropagation()}>
        <h2 className="text-lg font-bold">{title}</h2>
        <p className="mt-1.5 text-sm text-muted">{body}</p>
        <div className="mt-5 grid grid-cols-2 gap-2">
          <Button variant="ghost" onClick={onClose}>닫기</Button>
          <Button variant={danger ? 'danger' : 'primary'} onClick={onConfirm}>{confirmLabel}</Button>
        </div>
      </div>
    </div>
  );
}

export function Empty({ children, action }: { children: ReactNode; action?: { to: string; label: string } }) {
  return (
    <div className="px-6 py-12 text-center text-muted">
      {children}
      {action && <div className="mt-4"><Link to={action.to} className="inline-block rounded-xl bg-accent px-4 py-2.5 text-sm font-bold text-accent-ink">{action.label}</Link></div>}
    </div>
  );
}

export function Loading() {
  return <div className="py-16 text-center text-sm text-muted">불러오는 중…</div>;
}
