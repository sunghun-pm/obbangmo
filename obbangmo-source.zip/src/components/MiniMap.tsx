import { useEffect, useRef } from 'react';
import { ORIGIN } from '../lib/format';

export type Pin = { id: string; storeId: string; lat: number; lng: number; label: string; active: boolean };

const KAKAO_KEY = import.meta.env.VITE_KAKAO_MAP_KEY as string | undefined;

/* eslint-disable @typescript-eslint/no-explicit-any */
declare global { interface Window { kakao?: any } }

let kakaoLoading: Promise<void> | null = null;
function loadKakao(key: string) {
  if (window.kakao?.maps) return Promise.resolve();
  if (!kakaoLoading) {
    kakaoLoading = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = `https://dapi.kakao.com/v2/maps/sdk.js?appkey=${key}&autoload=false`;
      s.onload = () => window.kakao.maps.load(() => resolve());
      s.onerror = () => reject(new Error('kakao load failed'));
      document.head.appendChild(s);
    });
  }
  return kakaoLoading;
}

function KakaoMap({ pins, onPick }: { pins: Pin[]; onPick: (p: Pin) => void }) {
  const el = useRef<HTMLDivElement>(null);
  const pinsRef = useRef(pins);
  pinsRef.current = pins;
  useEffect(() => {
    let overlays: any[] = [];
    let map: any;
    let cancelled = false;
    loadKakao(KAKAO_KEY!).then(() => {
      if (cancelled || !el.current) return;
      const k = window.kakao.maps;
      map = new k.Map(el.current, { center: new k.LatLng(ORIGIN.lat, ORIGIN.lng), level: 5 });
      overlays = pinsRef.current.map((p) => {
        const node = document.createElement('button');
        node.textContent = p.label;
        node.className = `rounded-full px-2 py-0.5 font-mono text-[11px] font-semibold shadow ${p.active ? 'bg-accent text-accent-ink' : 'border border-line bg-surface-2 text-muted'}`;
        node.onclick = () => onPick(p);
        return new k.CustomOverlay({ position: new k.LatLng(p.lat, p.lng), content: node, yAnchor: 1.2, map });
      });
    }).catch(() => {});
    return () => { cancelled = true; overlays.forEach((o) => o.setMap(null)); };
  }, [pins.map((p) => p.id + p.label).join(), onPick]);
  return <div ref={el} className="h-[200px] w-full" />;
}

/** 키가 없을 때 쓰는 간이 지도: 좌표를 망원역 중심으로 투영해 핀을 놓는다 */
function SketchMap({ pins, onPick }: { pins: Pin[]; onPick: (p: Pin) => void }) {
  const span = 0.012;
  const pos = (lat: number, lng: number) => ({
    left: `${Math.min(92, Math.max(8, 50 + ((lng - ORIGIN.lng) / span) * 50))}%`,
    top: `${Math.min(90, Math.max(14, 50 - ((lat - ORIGIN.lat) / (span * 0.8)) * 50))}%`,
  });
  return (
    <div className="relative h-[200px] w-full">
      <svg viewBox="0 0 360 200" className="absolute inset-0 h-full w-full" aria-hidden="true" preserveAspectRatio="none">
        <rect width="360" height="200" fill="var(--map-land)" />
        <path d="M0 168 C 90 156, 200 186, 360 160 L360 200 L0 200Z" fill="var(--map-water)" />
        <g stroke="var(--map-road)" strokeLinecap="round" fill="none">
          <path d="M-10 50 L370 32" strokeWidth="9" /><path d="M150 -10 L190 170" strokeWidth="9" />
          <path d="M-10 118 L370 104" strokeWidth="6" /><path d="M60 0 L90 160" strokeWidth="5" /><path d="M270 0 L250 160" strokeWidth="5" />
        </g>
        <text x="300" y="190" fontSize="10" fill="var(--muted)">한강</text>
        <circle cx="180" cy="100" r="6" fill="var(--accent)" opacity=".25" /><circle cx="180" cy="100" r="3" fill="var(--accent)" />
        <text x="188" y="96" fontSize="10" fontWeight="600" fill="var(--muted)">망원역</text>
      </svg>
      {pins.map((p) => (
        <button key={p.id} type="button" onClick={() => onPick(p)} aria-label={p.label}
          style={pos(p.lat, p.lng)} className="absolute flex -translate-x-1/2 -translate-y-full flex-col items-center">
          <span className={`rounded-full px-2 py-0.5 font-mono text-[11px] font-semibold whitespace-nowrap ${p.active ? 'bg-accent text-accent-ink shadow' : 'border border-line bg-surface-2 text-muted'}`}>{p.label}</span>
          <span className={`h-1.5 w-0.5 ${p.active ? 'bg-accent' : 'bg-line'}`} />
        </button>
      ))}
      <span className="absolute right-2 bottom-1.5 rounded bg-surface/80 px-1.5 text-[10px] text-muted">간이 지도</span>
    </div>
  );
}

export default function MiniMap(props: { pins: Pin[]; onPick: (p: Pin) => void }) {
  return (
    <div className="mx-4 mb-3 overflow-hidden rounded-2xl border border-line">
      {KAKAO_KEY ? <KakaoMap {...props} /> : <SketchMap {...props} />}
    </div>
  );
}
