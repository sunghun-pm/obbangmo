const MESSAGES: Record<string, string> = {
  SOLD_OUT: '방금 마지막 박스가 다른 분께 예약됐어요. 결제는 진행되지 않았어요.',
  LIMIT_2: '이 박스는 한 사람이 2개까지 예약할 수 있어요.',
  TOO_LATE: '픽업이 시작돼서 취소할 수 없어요.',
  LOGIN_REQUIRED: '로그인이 필요해요.',
  BAD_QTY: '수량을 다시 확인해 주세요.',
  NOT_OWNER: '내 매장의 상품만 올릴 수 있어요.',
  ALREADY_OPEN: '이 상품은 오늘 이미 올렸어요.',
  BAD_WINDOW: '픽업 시간을 다시 확인해 주세요.',
  CANNOT_ADJUST: '예약된 수량보다 적게 줄일 수 없어요.',
  CANNOT_CLOSE: '이미 마감된 판매예요.',
  NOT_HELD: '결제 확인 시간이 지났어요. 다시 예약해 주세요.',
  NOT_CANCELABLE: '이미 처리된 예약이에요.',
  FORBIDDEN: '이 예약을 취소할 권한이 없어요.',
  NOT_FOUND: '예약을 찾을 수 없어요.',
  CODE_NOT_FOUND: '일치하는 예약이 없어요. 코드를 다시 확인해 주세요.',
};

/** Supabase/함수 오류에서 우리 오류 코드를 찾아 한국어 문장으로 바꾼다 */
export function errorCode(e: unknown): string | null {
  const msg = typeof e === 'string' ? e : (e as { message?: string })?.message ?? '';
  const m = msg.match(/[A-Z][A-Z_0-9]{2,}/g);
  return m?.find((c) => c in MESSAGES) ?? null;
}
export function friendly(e: unknown, fallback = '잠시 후 다시 시도해 주세요.') {
  const code = errorCode(e);
  return code ? MESSAGES[code] : fallback;
}
