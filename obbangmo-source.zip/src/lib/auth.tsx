import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from './supabase';

type Role = 'user' | 'owner';
type AuthState = {
  ready: boolean;
  session: Session | null;
  userId: string | null;
  role: Role | null;
  nickname: string | null;
  signOut: () => Promise<void>;
};

const Ctx = createContext<AuthState>({
  ready: false, session: null, userId: null, role: null, nickname: null, signOut: async () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(false);
  const [profile, setProfile] = useState<{ role: Role; nickname: string | null } | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true); });
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => data.subscription.unsubscribe();
  }, []);

  const uid = session?.user.id ?? null;
  useEffect(() => {
    if (!uid) { setProfile(null); return; }
    let alive = true;
    supabase.from('profiles').select('role,nickname').eq('id', uid).maybeSingle().then(({ data }) => {
      if (!alive) return;
      const metaRole = (session?.user.user_metadata?.role as Role | undefined) ?? 'user';
      setProfile(data ? { role: data.role as Role, nickname: data.nickname } : { role: metaRole, nickname: null });
    });
    return () => { alive = false; };
  }, [uid, session?.user.user_metadata?.role]);

  const value: AuthState = {
    ready: ready && (!uid || profile !== null),
    session,
    userId: uid,
    role: profile?.role ?? null,
    nickname: profile?.nickname ?? null,
    signOut: async () => { await supabase.auth.signOut(); },
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useAuth = () => useContext(Ctx);
