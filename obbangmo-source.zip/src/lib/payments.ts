import { supabase } from './supabase';

export const TOSS_CLIENT_KEY = (import.meta.env.VITE_TOSS_CLIENT_KEY as string | undefined) || '';

/** Edge Function 호출. 함수가 돌려준 오류 코드를 message에 담아 던진다. */
export async function callFn<T>(name: string, body: Record<string, unknown>): Promise<T> {
  const { data, error } = await supabase.functions.invoke(name, { body });
  if (error) {
    let msg = error.message;
    const ctx = (error as { context?: Response }).context;
    if (ctx && typeof ctx.json === 'function') {
      try { const j = await ctx.json(); msg = j.code || j.message || msg; } catch { /* keep message */ }
    }
    throw new Error(msg);
  }
  return data as T;
}

export const confirmPayment = (p: { orderId: string; amount: number; paymentKey?: string; demo?: boolean }) =>
  callFn<{ reservationId: string }>('confirm-payment', p);

export const cancelReservation = (id: string) => callFn<{ ok: true; refunded: boolean }>('cancel-reservation', { id });
