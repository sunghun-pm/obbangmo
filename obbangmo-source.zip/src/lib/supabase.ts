import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anon = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const supabaseConfigured = Boolean(url && anon);

export const supabase = createClient(url || 'http://localhost:54321', anon || 'missing-key', {
  auth: { persistSession: true, autoRefreshToken: true },
});

export type Store = {
  id: string;
  owner_id: string | null;
  name: string;
  address: string | null;
  lat: number;
  lng: number;
};

export type Product = {
  id: string;
  store_id: string;
  title: string;
  category: string;
  orig_price: number;
  price: number;
  items_desc: string;
  allergens: string[];
  default_qty: number;
  default_start: string;
  default_end: string;
  photo_url: string | null;
  deleted_at: string | null;
};

export type Listing = {
  id: string;
  product_id: string;
  store_id: string;
  sale_date: string;
  title: string;
  category: string;
  orig_price: number;
  price: number;
  items_desc: string;
  allergens: string[];
  photo_url: string | null;
  qty_total: number;
  qty_left: number;
  pickup_start: string;
  pickup_end: string;
  closed_at: string | null;
  stores?: Pick<Store, 'name' | 'address' | 'lat' | 'lng'> | null;
};

export type ReservationStatus = 'held' | 'booked' | 'picked' | 'expired' | 'canceled' | 'no_show';

export type Reservation = {
  id: string;
  listing_id: string;
  store_id: string;
  sale_date: string;
  user_id: string;
  qty: number;
  amount: number;
  pickup_code: string;
  order_id: string;
  status: ReservationStatus;
  hold_expires_at: string | null;
  payment_key: string | null;
  booked_at: string | null;
  picked_at: string | null;
  canceled_at: string | null;
  created_at: string;
  listings?: (Listing & { stores?: Pick<Store, 'name' | 'address'> | null }) | null;
};
