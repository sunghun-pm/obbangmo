import type { Listing, Reservation } from './supabase';

export const ORIGIN = { lat: 37.556, lng: 126.9101, name: '망원동' };
export const CATEGORIES = ['빵', '베이글', '디저트'] as const;
export const ALLERGENS = ['밀', '우유', '계란', '대두', '견과류', '땅콩', '참깨'] as const;
export const WINDOWS: [string, string][] = [
  ['18:30', '20:00'],
  ['19:00', '20:30'],
  ['20:00', '21:30'],
];

export const won = (n: number) => `${n.toLocaleString('ko-KR')}원`;
export const pct = (price: number, orig: number) => Math.round((1 - price / orig) * 100);

/** 한국 시간 기준 오늘 날짜 (YYYY-MM-DD) */
export function kstToday(now = Date.now()) {
  return new Date(now + 9 * 3600_000).toISOString().slice(0, 10);
}

/** ISO 시각 → 한국 시간 HH:MM */
export function hm(iso: string) {
  const d = new Date(new Date(iso).getTime() + 9 * 3600_000);
  return d.toISOString().slice(11, 16);
}
export const windowText = (l: Pick<Listing, 'pickup_start' | 'pickup_end'>) => `${hm(l.pickup_start)}–${hm(l.pickup_end)}`;
export const timeShort = (t: string) => t.slice(0, 5);

export function durationText(ms: number) {
  const m = Math.max(1, Math.round(ms / 60000));
  const h = Math.floor(m / 60);
  const mm = m % 60;
  return [h ? `${h}시간` : '', mm ? `${mm}분` : ''].filter(Boolean).join(' ');
}

/** 두 좌표 사이 직선거리(m) */
export function distanceM(lat: number, lng: number, from = ORIGIN) {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat - from.lat);
  const dLng = toRad(lng - from.lng);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(from.lat)) * Math.cos(toRad(lat)) * Math.sin(dLng / 2) ** 2;
  return Math.round(2 * R * Math.asin(Math.sqrt(a)));
}
export const distText = (m: number) => (m < 1000 ? `${m}m` : `${(m / 1000).toFixed(1)}km`);

export type ListingState = 'pickup' | 'open' | 'soldout' | 'ended';
export function listingState(l: Listing, now = Date.now()): ListingState {
  const start = new Date(l.pickup_start).getTime();
  const end = new Date(l.pickup_end).getTime();
  if (now >= end) return 'ended';
  if (l.qty_left <= 0 || l.closed_at) return 'soldout';
  if (now >= start) return 'pickup';
  return 'open';
}
export const listingOrder: Record<ListingState, number> = { pickup: 0, open: 1, soldout: 2, ended: 3 };
export const canReserve = (s: ListingState) => s === 'pickup' || s === 'open';

export type TicketState = 'booked' | 'ready' | 'picked' | 'no_show' | 'canceled' | 'held' | 'expired';
export function ticketState(r: Reservation, now = Date.now()): TicketState {
  if (r.status !== 'booked') return r.status;
  const l = r.listings;
  if (!l) return 'booked';
  if (now >= new Date(l.pickup_end).getTime()) return 'no_show';
  if (now >= new Date(l.pickup_start).getTime()) return 'ready';
  return 'booked';
}
export const TICKET_LABEL: Record<TicketState, string> = {
  held: '결제 대기',
  booked: '예약됨',
  ready: '지금 픽업 가능',
  picked: '픽업 완료',
  no_show: '미수령',
  canceled: '취소됨',
  expired: '선점 만료',
};
export const TICKET_TONE: Record<TicketState, string> = {
  held: 'bg-surface-2 text-muted',
  booked: 'bg-accent-soft text-accent',
  ready: 'bg-ok-soft text-ok',
  picked: 'bg-surface-2 text-muted',
  no_show: 'bg-danger-soft text-danger',
  canceled: 'bg-danger-soft text-danger',
  expired: 'bg-surface-2 text-muted',
};
