import { useEffect, useRef, useState } from 'react';
import { supabase } from './supabase';

/** 현재 시각. 상태(픽업 가능, 판매 종료 등)는 이 값으로 화면에서 계산한다. */
export function useNow(intervalMs = 15000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

/**
 * 테이블 변경을 Realtime으로 구독하고, 바뀌면 reload를 부른다.
 * Realtime이 끊겨도 동작하도록 pollMs마다 다시 불러온다.
 */
export function useLiveReload(tables: string[], reload: () => void, opts: { filter?: string; pollMs?: number } = {}) {
  const ref = useRef(reload);
  ref.current = reload;
  const key = tables.join(',') + '|' + (opts.filter ?? '');
  useEffect(() => {
    const ch = supabase.channel('live:' + key + ':' + Math.random().toString(36).slice(2));
    for (const t of tables) {
      ch.on('postgres_changes', { event: '*', schema: 'public', table: t, ...(opts.filter ? { filter: opts.filter } : {}) }, () => ref.current());
    }
    ch.subscribe();
    const poll = setInterval(() => ref.current(), opts.pollMs ?? 20000);
    const onFocus = () => ref.current();
    window.addEventListener('focus', onFocus);
    return () => {
      clearInterval(poll);
      window.removeEventListener('focus', onFocus);
      supabase.removeChannel(ch);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, opts.pollMs]);
}
