import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: 'tests',
  timeout: 60_000,
  use: {
    baseURL: process.env.BASE_URL ?? 'http://127.0.0.1:5173',
    viewport: { width: 390, height: 844 },
    locale: 'ko-KR',
    timezoneId: 'Asia/Seoul',
  },
  reporter: [['list']],
  projects: [{ name: 'chromium', use: { launchOptions: { executablePath: '/opt/pw-browsers/chromium' } } }],
});
