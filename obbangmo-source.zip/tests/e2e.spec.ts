import { test, expect, type Page } from '@playwright/test';

const stamp = Date.now();
const OWNER = { email: `owner${stamp}@test.dev`, pw: 'testpass123' };
const USER = { email: `user${stamp}@test.dev`, pw: 'testpass123' };
const shots = 'tests/shots';
const STORE = `소금결 베이커리 ${String(stamp).slice(-3)}`;

async function signup(page: Page, who: { email: string; pw: string }, role: 'user' | 'owner') {
  await page.goto('/login');
  await page.getByRole('tab', { name: '회원가입' }).click();
  await page.getByText(role === 'owner' ? '빵집 사장님이에요' : '박스 사러 왔어요').click();
  await page.locator('#email').fill(who.email);
  await page.locator('#password').fill(who.pw);
  await page.getByRole('button', { name: '가입하기' }).click();
}

test.describe.configure({ mode: 'serial' });

test('사장님: 매장 등록 → 상품 등록(검증) → 오늘 올리기', async ({ page }) => {
  await signup(page, OWNER, 'owner');
  await expect(page.getByRole('heading', { name: '매장 등록' })).toBeVisible();
  await page.screenshot({ path: `${shots}/01-store-setup.png` });
  await page.locator('#store-name').fill(STORE);
  await page.locator('#store-address').fill('서울 마포구 망원동 (예시)');
  await page.locator('#store-lat').fill('37.5552');
  await page.locator('#store-lng').fill('126.9062');
  await page.getByRole('button', { name: '매장 등록하기' }).click();
  await expect(page.getByText('등록된 상품이 없어요')).toBeVisible();

  await page.getByRole('link', { name: '상품 등록하기' }).click();
  await page.locator('#title').fill('빵 마감박스');
  await page.locator('#orig').fill('10000');
  await page.locator('#price').fill('5100');
  await page.locator('#items').fill('소금빵, 바게트 등 그날 남은 빵 3~5개');
  await page.getByRole('button', { name: '상품 등록하기' }).click();
  await expect(page.locator('#discount')).toContainText('최대 5,000원');
  await page.screenshot({ path: `${shots}/02-product-validation.png` });

  await page.locator('#orig').fill('15000');
  await page.locator('#price').fill('4900');
  await expect(page.locator('#discount')).toContainText('67% 할인');
  await page.getByRole('button', { name: '밀', exact: true }).click();
  await page.getByRole('button', { name: '우유' }).click();
  await page.getByRole('button', { name: '상품 등록하기' }).click();

  await expect(page.getByRole('heading', { name: '오늘 판매' })).toBeVisible();
  // 오늘 픽업 시간을 늦은 시간대로 (테스트가 저녁에 돌아도 통과하도록)
  await page.getByRole('button', { name: '조건 바꾸기' }).click();
  await page.getByRole('button', { name: '20:00–21:30' }).click();
  await page.getByRole('button', { name: '오늘 올리기' }).click();
  await expect(page.getByText('판매 중')).toBeVisible();
  await page.screenshot({ path: `${shots}/03-owner-today.png` });
  await page.getByRole('button', { name: '오늘 올리기' }).count().then((n) => expect(n).toBe(0));
});

test('사용자: 홈 → 상세 → 예약 → 데모 결제 → 티켓, 사장님이 코드로 픽업 처리', async ({ page, browser }) => {
  await page.goto('/');
  await expect(page.getByText(STORE)).toBeVisible();
  await page.screenshot({ path: `${shots}/04-home.png`, fullPage: true });

  await signup(page, USER, 'user');
  await expect(page).toHaveURL(/\/$/);
  await page.getByRole('link', { name: new RegExp(STORE) }).click();
  await expect(page.getByText('밀, 우유 성분이 포함될 수 있어요')).toBeVisible();
  await page.screenshot({ path: `${shots}/05-detail.png`, fullPage: true });
  await page.getByRole('button', { name: /예약하기/ }).click();

  await expect(page.getByRole('heading', { name: '예약 확인' })).toBeVisible();
  await expect(page.getByText(/선점 남은 시간/)).toBeVisible();
  const pay = page.getByRole('button', { name: /데모 결제하기/ });
  await expect(pay).toBeDisabled();
  await page.locator('#agree').check();
  await page.screenshot({ path: `${shots}/06-checkout.png`, fullPage: true });
  await pay.click();

  const code = page.getByTestId('pickup-code');
  await expect(code).toHaveText(/^\d{4}$/);
  const pickupCode = (await code.textContent())!;
  await expect(page.getByText('예약됨')).toBeVisible();
  await page.screenshot({ path: `${shots}/07-ticket.png`, fullPage: true });

  // 사장님 화면: 예약자 탭에서 코드로 픽업 완료
  const ctx = await browser.newContext();
  const owner = await ctx.newPage();
  await owner.goto('/login');
  await owner.locator('#email').fill(OWNER.email);
  await owner.locator('#password').fill(OWNER.pw);
  await owner.getByRole('button', { name: '로그인' }).click();
  await owner.getByRole('link', { name: /예약자/ }).click();
  await expect(owner.getByText(`코드 ${pickupCode}`)).toBeVisible();
  await owner.locator('#codein').fill('0000');
  await owner.getByRole('button', { name: '확인' }).click();
  await expect(owner.getByText('일치하는 예약이 없어요')).toBeVisible();
  await owner.locator('#codein').fill(pickupCode);
  await owner.getByRole('button', { name: '확인' }).click();
  await expect(owner.getByText(`코드 ${pickupCode} 픽업 완료로 처리했어요`)).toBeVisible();
  await owner.screenshot({ path: `${shots}/08-owner-orders.png`, fullPage: true });
  await expect(owner.locator('nav a[href="/owner/orders"] span.num')).toHaveCount(0);

  // 사용자 티켓이 새로고침 없이 '픽업 완료'로 바뀐다 (실시간 또는 10초 폴링)
  await expect(page.getByText('픽업 완료').first()).toBeVisible({ timeout: 15000 });
  await ctx.close();
});

test('사용자: 예약 후 취소하면 재고가 돌아온다', async ({ page }) => {
  await page.goto('/login');
  await page.locator('#email').fill(USER.email);
  await page.locator('#password').fill(USER.pw);
  await page.getByRole('button', { name: '로그인' }).click();
  await page.getByRole('link', { name: /망원 베이글랩/ }).click();
  const before = Number(await page.locator('dd b.num').first().textContent());
  await page.getByRole('button', { name: /예약하기/ }).click();
  await page.locator('#agree').check();
  await page.getByRole('button', { name: /데모 결제하기/ }).click();
  await expect(page.getByTestId('pickup-code')).toBeVisible();
  await page.getByRole('button', { name: '예약 취소' }).click();
  await page.getByRole('dialog').getByRole('button', { name: '예약 취소' }).click();
  await expect(page.getByText('취소됨')).toBeVisible();
  await page.goto('/');
  await page.getByRole('link', { name: /망원 베이글랩/ }).click();
  await expect(page.locator('dd b.num').first()).toHaveText(String(before));
});
